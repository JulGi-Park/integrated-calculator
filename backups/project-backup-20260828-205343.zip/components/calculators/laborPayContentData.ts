export const laborPayBaseDate = "2026-08-15";
export const laborPayMinimumWageText = "2026년 최저임금 시간급 10,320원";

export const laborPayOfficialSources = [
  {
    organization: "국가법령정보센터",
    title: "근로기준법 제55조(휴일)",
    url: "https://www.law.go.kr/lsLinkCommonInfo.do?ancYnChk=&chrClsCd=010202&lsJoLnkSeq=1015677471",
    supports: "1주 평균 1회 이상의 유급휴일 보장 기준",
  },
  {
    organization: "국가법령정보센터",
    title: "근로기준법 제18조 제3항(단시간근로자의 근로조건)",
    url: "https://law.go.kr/LSW/lsLinkProc.do?joNo=001800&lnkJoNo=undefined&lsClsCd=L&lsId=001872&lsNm=%EA%B7%BC%EB%A1%9C%EA%B8%B0%EC%A4%80%EB%B2%95&mode=4",
    supports: "4주 평균 1주 소정근로시간이 15시간 미만인 근로자에게 제55조를 적용하지 않는 기준",
  },
  {
    organization: "국가법령정보센터",
    title: "근로기준법 제2조 제1항 제8호·제50조(소정근로시간·근로시간)",
    url: "https://www.law.go.kr/LSW/lsInfoP.do?ancYnChk=0&chrClsCd=010202&efYd=20241022&joNo=006100&lsiSeq=265959&urlMode=lsInfoP",
    supports: "일반 근로형태의 소정근로시간은 1주 40시간·1일 8시간 범위에서 정한다는 기준",
  },
  {
    organization: "국가법령정보센터",
    title: "근로기준법 제51조(탄력적 근로시간제)",
    url: "https://law.go.kr/LSW/lsLinkCommonInfo.do?chrClsCd=010202&lsJoLnkSeq=1025590263",
    supports: "탄력적 근로시간제에서는 일정 요건 아래 특정일 근로시간이 제50조 기준을 초과할 수 있어 이 계산기의 일반 안내 범위에서 제외",
  },
  {
    organization: "국가법령정보센터",
    title: "근로기준법 시행령 제30조(휴일)",
    url: "https://www.law.go.kr/LSW//lsLinkCommonInfo.do?chrClsCd=010202&lspttninfSeq=148916",
    supports: "1주 동안의 소정근로일 개근 요건",
  },
  {
    organization: "대법원",
    title: "2022다291153 임금 판결",
    url: "https://www.law.go.kr/LSW/precInfoP.do?mode=0&precSeq=608507",
    supports:
      "유급 주휴시간은 원칙적으로 1주 소정근로시간을 1주 소정근로일 수로 나눈 1일 평균 소정근로시간으로 산정",
  },
  {
    organization: "고용노동부 고객상담센터",
    title: "주휴수당 및 근로계약 안내",
    url: "https://www.moel.go.kr/mainpop2.do",
    supports: "4주 평균 1주 소정근로시간 15시간 이상과 개근 요건",
  },
  {
    organization: "고용노동부",
    title: "2026년 적용 최저임금 고시",
    url: "https://www.moel.go.kr/info/lawinfo/instruction/view.do?bbs_seq=20250800121",
    supports: "2026년 적용 최저임금액 고시",
  },
  {
    organization: "최저임금위원회",
    title: "연도별 최저임금 결정현황",
    url: "https://www.minimumwage.go.kr/minWage/policy/decisionMain.do",
    supports: "2026년 시간급 10,320원, 8시간 일급 82,560원, 209시간 월 환산액 2,156,880원",
  },
] as const;

export const laborPayFormulas = [
  {
    title: "주휴시간",
    formula: "1주 소정근로시간 ÷ 적용 소정근로일 수(5일 미만이면 5일)",
  },
  {
    title: "주휴수당",
    formula: "주휴시간 × 시급",
  },
  {
    title: "기본 근로임금",
    formula: "1주 실제 근로시간 × 시급",
  },
  {
    title: "예상 주급 (주휴 포함)",
    formula: "기본 근로임금 + 주휴수당",
  },
] as const;

export const laborPayExampleInput = [
  { label: "시급", value: "10,320원" },
  { label: "근무 일정", value: "하루 4시간 × 주 5일" },
  { label: "1주 소정근로시간", value: "20시간" },
  { label: "1주 소정근로일 수", value: "5일" },
  { label: "1주 실제 근로시간", value: "20시간" },
  { label: "개근 여부", value: "개근" },
] as const;

export const laborPayExampleResult = [
  { label: "기본 근로임금 (주휴 전)", value: "206,400원" },
  { label: "예상 주휴시간", value: "4시간" },
  { label: "예상 주휴수당", value: "41,280원" },
  { label: "예상 주급 (주휴 포함)", value: "247,680원" },
] as const;

export const laborPayBoundaryExamples = [
  {
    title: "주 15시간 경계",
    description:
      "시급 10,320원, 주 소정근로시간 15시간, 개근이면 주휴 3시간(30,960원)이 발생할 수 있습니다.",
  },
  {
    title: "주 15시간 미만",
    description:
      "주 소정근로시간이 14시간이면 이 계산기는 주휴수당을 0원으로 표시하고 기본 근로임금만 계산합니다.",
  },
] as const;

export const laborPayExclusions = [
  "근로자성, 근로계약 형태, 휴일 대체, 결근·지각·조퇴 처리 기준",
  "퇴사하는 주, 교대근무, 단시간 근로자의 실제 사업장 운영 기준",
  "세금·4대보험 공제, 연장·야간·휴일근로수당, 이미 지급된 고정수당",
] as const;

export const laborPayFaqs = [
  {
    question: "알바 주급은 어떻게 계산하나요?",
    answer:
      "시급에 1주 실제 근로시간을 곱한 기본 근로임금에, 지급 요건을 충족하는 경우 주휴수당을 더합니다. 계산기는 두 금액과 주휴 포함 예상 주급을 나누어 보여줍니다.",
  },
  {
    question: "주휴수당을 포함하면 주급은 얼마인가요?",
    answer:
      "예상 주급은 기본 근로임금과 해당 주의 주휴수당을 합산한 금액입니다. 시급, 소정근로시간, 실제 근로시간, 개근 여부를 입력하면 확인할 수 있습니다.",
  },
  {
    question: "주 15시간 미만도 주휴수당을 받을 수 있나요?",
    answer:
      "이 계산기는 4주 평균 또는 1주 소정근로시간이 15시간 미만이면 주휴수당을 0원으로 표시합니다. 실제 적용은 근로계약과 근무 형태를 함께 확인해야 합니다.",
  },
  {
    question: "하루 근무시간이 다르면 주급은 어떻게 계산하나요?",
    answer:
      "요일별 시간이 달라도 1주 소정근로시간과 1주 실제 근로시간의 합계, 근로계약상 1주 소정근로일 수를 입력해 계산할 수 있습니다. 교대제·격일제처럼 주 단위 입력만으로 정확히 표현하기 어려운 형태는 계약·취업규칙을 함께 확인하세요.",
  },
  {
    question: "월급제가 아니라 시급제도 계산할 수 있나요?",
    answer:
      "네. 시급과 주간 근무시간을 입력하는 시급제·시간제 근로자용 계산기입니다. 월급제는 주휴수당이 이미 포함됐을 수 있으므로 급여명세서와 계약서를 함께 확인하세요.",
  },
  {
    question: "주휴수당은 주 15시간만 넘으면 무조건 받을 수 있나요?",
    answer:
      "아닙니다. 4주 평균 1주 소정근로시간이 15시간 이상이고, 소정근로일을 개근했는지 등을 함께 봐야 합니다.",
  },
  {
    question: "결근하면 주휴수당을 받을 수 없나요?",
    answer:
      "소정근로일을 개근하지 않은 주는 주휴수당 대상이 아닐 수 있습니다. 결근 사유와 사업장 기준을 함께 확인해야 합니다.",
  },
  {
    question: "지각이나 조퇴가 있으면 어떻게 되나요?",
    answer:
      "지각·조퇴만으로 항상 제외된다고 단정할 수는 없습니다. 근로계약, 취업규칙, 실제 임금 산정 방식을 확인해야 합니다.",
  },
  {
    question: "주휴수당 계산식은 어떻게 되나요?",
    answer:
      "주휴시간은 원칙적으로 1주 소정근로시간을 1주 소정근로일 수로 나누어 계산합니다. 일반적인 경우 소정근로일이 5일 미만이면 5일 기준으로 보정하고, 주휴수당은 주휴시간에 시급을 곱합니다. 이 계산기는 1주 40시간·1일 평균 8시간 이하의 일반적인 근무형태를 안내하며, 탄력적·교대제 등은 근무표와 제도 적용 여부를 함께 확인해야 합니다.",
  },
  {
    question: "주급에 주휴수당은 어떻게 포함되나요?",
    answer:
      "주급은 1주 실제 근로시간에 대한 기본 근로임금과 해당 주의 주휴수당을 더해 계산합니다. 계산기는 두 금액을 각각 보여주고 주휴 포함 예상 주급으로 합산하며, 개근·소정근로일 등 지급 요건을 충족하지 않으면 주휴수당이 달라질 수 있습니다.",
  },
  {
    question: "알바도 주휴수당을 받을 수 있나요?",
    answer:
      "아르바이트도 근로자에 해당하고 요건을 충족하면 주휴수당 대상이 될 수 있습니다.",
  },
  {
    question: "5인 미만 사업장도 해당되나요?",
    answer:
      "주휴수당은 사업장 규모와 무관하게 문제될 수 있습니다. 다만 구체적인 적용은 근로계약과 실제 근무 형태를 확인해야 합니다.",
  },
  {
    question: "시급이 최저임금보다 낮으면 어떻게 표시되나요?",
    answer:
      "2026년 최저임금 10,320원보다 낮은 시급을 입력하면 확인 필요 경고를 표시합니다. 법 위반 확정 표현은 하지 않습니다.",
  },
  {
    question: "퇴사하는 주에도 주휴수당이 나오나요?",
    answer:
      "퇴사일, 소정근로일, 다음 주 근로 예정 여부 등 사정에 따라 판단이 달라질 수 있어 고용노동부나 노무 전문가 확인이 필요합니다.",
  },
  {
    question: "실제 급여명세서와 계산 결과가 다른 이유는 무엇인가요?",
    answer:
      "세금, 4대보험, 사업장 지급 방식, 근무표 변경, 이미 포함된 수당 등이 반영되지 않아 실제 지급액과 다를 수 있습니다.",
  },
  {
    question: "한 달 주휴수당은 어떻게 계산하나요?",
    answer:
      "이 계산기는 1주 단위의 주휴수당을 계산합니다. 한 달 금액은 해당 월에 주휴수당이 발생한 주별 금액을 합산해야 하며, 근무표와 소정근로일이 달마다 달라질 수 있어 주급을 단순히 4배 또는 4.345배로 자동 환산하지 않습니다.",
  },
] as const;

export const laborPayWebApplicationJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "주휴수당 계산기",
  url: "https://gyesanbox.kr/calculators/labor-pay/",
  applicationCategory: "FinanceApplication",
  operatingSystem: "Web",
  description:
    "근무시간, 시급, 개근 여부를 입력해 예상 주휴수당과 주휴 포함 주급을 계산하는 계산기",
};

export const laborPayBreadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "홈",
      item: "https://gyesanbox.kr/",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "계산기 목록",
      item: "https://gyesanbox.kr/calculators/",
    },
    {
      "@type": "ListItem",
      position: 3,
      name: "주휴수당 계산기",
      item: "https://gyesanbox.kr/calculators/labor-pay/",
    },
  ],
};

export const laborPayFaqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: laborPayFaqs.map(({ question, answer }) => ({
    "@type": "Question",
    name: question,
    acceptedAnswer: {
      "@type": "Answer",
      text: answer,
    },
  })),
};
