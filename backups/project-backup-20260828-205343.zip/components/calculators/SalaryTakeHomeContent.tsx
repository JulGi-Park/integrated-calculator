import { SALARY_TAKE_HOME_POLICY_2026 } from "@/lib/calculators/salary-take-home/policy";
import {
  salaryTakeHomeCalculationCriteria,
  salaryTakeHomeExampleInputItems,
  salaryTakeHomeExampleResultItems,
  salaryTakeHomeExclusions,
  salaryTakeHomeFaqs,
  salaryTakeHomeSources,
} from "./salaryTakeHomeContentData";
import styles from "./SalaryTakeHomeContent.module.css";

function formatKoreanDate(value: string): string {
  const [year, month, day] = value.split("-").map(Number);
  return `${year}년 ${month}월 ${day}일`;
}

function formatWon(value: number): string {
  return `${value.toLocaleString("ko-KR")}원`;
}

export function SalaryTakeHomeContent() {
  const policy = SALARY_TAKE_HOME_POLICY_2026;

  return (
    <div className={styles.content}>
      <section className={styles.section} aria-labelledby="use-case-title">
        <div className={styles.sectionHeading}>
          <h2 id="use-case-title">언제 쓰는 계산기인가요?</h2>
          <p>
            연봉 제안, 이직 검토, 월 예산 계획처럼 세전 연봉이 실제 월급으로
            어느 정도 바뀌는지 가늠할 때 사용합니다. 입력값은 일반 근로자의
            예상 공제액을 계산하기 위한 조건이며 개인별 급여명세서와 다를 수
            있습니다.
          </p>
        </div>
        <div className={styles.interpretationGrid}>
          <article className={styles.infoCard}>
            <h3>입력값 안내</h3>
            <p>
              연봉은 퇴직금을 제외한 세전 금액, 월 비과세액은 급여명세서에
              매월 비과세로 표시되는 금액을 입력합니다.
            </p>
          </article>
          <article className={styles.infoCard}>
            <h3>자주 틀리는 부분</h3>
            <p>
              공제대상 가족 수는 본인을 포함하며, 자녀 수는 간이세액표 기준의
              요건을 만족하는 자녀만 입력해야 합니다.
            </p>
          </article>
          <article className={styles.infoCard}>
            <h3>사용자 우선 안내</h3>
            <p>
              결과는 급여 협상이나 생활비 계획을 돕기 위한 참고값이며, 회사의
              확정 급여명세서나 세무 신고 자료를 대신하지 않습니다.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="interpretation-title">
        <div className={styles.sectionHeading}>
          <h2 id="interpretation-title">결과를 이렇게 해석하세요</h2>
          <p>
            실수령액은 입력값과 현재 공개 정책을 기준으로 계산한 예상치이며,
            실제 급여명세서의 확정 금액은 아닙니다.
          </p>
        </div>
        <div className={styles.interpretationGrid}>
          <article className={styles.infoCard}>
            <h3>월 예상 실수령액</h3>
            <p>월 급여에서 여섯 가지 공제 항목을 차감한 예상 금액입니다.</p>
          </article>
          <article className={styles.infoCard}>
            <h3>연간 예상 실수령액</h3>
            <p>
              월 예상 실수령액의 12배이며 상여나 월별 급여 변동은 포함하지
              않습니다.
            </p>
          </article>
          <article className={styles.infoCard}>
            <h3>입력 조건의 영향</h3>
            <p>
              비과세액, 공제대상 가족 수와 자녀 수에 따라 과세 급여와 소득세가
              달라질 수 있습니다.
            </p>
          </article>
          <article className={styles.infoCard}>
            <h3>기준소득월액과 월급은 다를 수 있어요</h3>
            <p>
              실수령액은 세금과 사회보험료를 모두 뺀 결과입니다. 국민연금의
              기준소득월액과 건강보험의 보수월액은 같은 값이 아니며, 비과세
              급여·상한과 신고 시점에 따라 계약상 월급과 달라질 수 있습니다.
            </p>
          </article>
        </div>
        <p className={styles.note}>
          저소득 구간에서는 소득세가 0원일 수 있습니다. 국민연금은
          기준소득월액 상한을 초과한 소득 전체에 계속 비례하지 않으며, 실제
          신고 보수월액과 회사별 급여 처리 방식에 따라 결과가 달라질 수
          있습니다.
        </p>
      </section>

      <section className={styles.section} aria-labelledby="salary-base-income-title">
        <div className={styles.sectionHeading}>
          <h2 id="salary-base-income-title">
            기준소득월액과 실수령액은 왜 다른가요?
          </h2>
          <p>
            두 금액은 이름이 비슷해도 쓰임과 계산 단계가 다릅니다. 급여명세서나
            공단에서 본 금액을 이 계산기의 실수령액과 바로 비교하지 마세요.
          </p>
        </div>
        <div className={styles.interpretationGrid}>
          <article className={styles.infoCard}>
            <h3>계약상 월급과 과세 대상 급여</h3>
            <p>
              계약상 월급은 급여를 정할 때의 금액이고, 이 계산기는 입력한 월
              비과세액을 반영해 월 과세 급여를 추정합니다. 실제 비과세 적용은
              수당의 성격과 급여명세서 항목을 기준으로 확인해야 합니다.
            </p>
          </article>
          <article className={styles.infoCard}>
            <h3>국민연금 기준소득월액</h3>
            <p>
              국민연금 기준소득월액은 보험료와 급여 산정을 위한 신고 기준입니다.
              국민연금에 적용하는 상·하한과 신고 기준은 실수령액 자체를 뜻하지
              않습니다.
            </p>
          </article>
          <article className={styles.infoCard}>
            <h3>건강보험·고용보험의 보수</h3>
            <p>
              건강보험의 보수월액과 고용보험의 보수는 국민연금 기준소득월액과
              같은 명칭이나 신고 구조가 아닐 수 있습니다. 실제 고지와 정산은
              회사의 신고 내역을 확인해야 합니다.
            </p>
          </article>
        </div>
        <aside className={styles.policyNotice} aria-label="기준소득월액과 실수령액 비교 예시">
          <strong>짧은 예시</strong>
          <p>
            월 급여가 400만원이고 급여명세서상 월 비과세액이 20만원이라면,
            이 계산기는 380만원을 월 과세 급여로 사용해 각 공제 항목을
            예상합니다. 380만원은 국민연금 기준소득월액이나 실수령액이라는
            뜻이 아니며, 실제 신고 금액과 원천징수 결과는 항목별 기준과 회사
            처리에 따라 달라질 수 있습니다.
          </p>
        </aside>
      </section>

      <section className={styles.section} aria-labelledby="criteria-title">
        <div className={styles.sectionHeading}>
          <h2 id="criteria-title">2026년 계산 기준</h2>
          <p>
            기준 확인일은 {formatKoreanDate(policy.verifiedAt)}이며, 화면의
            정책값과 같은 데이터로 설명합니다.
          </p>
        </div>
        <dl className={styles.criteriaList}>
          {salaryTakeHomeCalculationCriteria.map(({ title, description }) => (
            <div key={title}>
              <dt>{title}</dt>
              <dd>{description}</dd>
            </div>
          ))}
        </dl>
        <aside className={styles.policyNotice} aria-label="국민연금 적용 기준">
          <strong>국민연금 기준소득월액 적용 안내</strong>
          <p>
            현재 하한 {formatWon(policy.nationalPension.standardMonthlyIncomeMinimum)},
            상한 {formatWon(policy.nationalPension.standardMonthlyIncomeMaximum)}
            을 {formatKoreanDate(policy.nationalPension.ceilingEffectiveFrom)}부터{" "}
            {formatKoreanDate(policy.nationalPension.ceilingEffectiveTo)}까지
            적용합니다. 기준소득월액 상·하한은 매년 7월부터 1년간 적용되므로,
            다음 적용 기간의 기준은 국민연금공단 최신 안내를 확인해 주세요.
          </p>
          <p>
            기준소득월액은 모든 공제에 공통으로 적용되는 하나의 값이 아닙니다.
            이 계산기는 월 과세 급여를 바탕으로 국민연금 상·하한을 적용하고,
            건강보험·장기요양보험·고용보험과 세금은 각 항목의 기준으로
            예상합니다. 급여명세서와 차이가 크면 회사의 신고 기준과 과세·비과세
            항목을 함께 확인하세요.
          </p>
        </aside>
      </section>

      <section className={styles.section} aria-labelledby="example-title">
        <div className={styles.sectionHeading}>
          <h2 id="example-title">계산 예시</h2>
          <p>
            아래 금액은 고정한 연봉·부양가족·비과세 조건으로 계산한 예시
            결과입니다.
          </p>
        </div>
        <div className={styles.exampleGrid}>
          <article className={styles.exampleCard}>
            <h3>예시 입력</h3>
            <dl>
              {salaryTakeHomeExampleInputItems.map(({ label, value }) => (
                <div key={label}>
                  <dt>{label}</dt>
                  <dd>{value}</dd>
                </div>
              ))}
            </dl>
          </article>
          <article className={styles.exampleCard}>
            <h3>예시 결과</h3>
            <dl>
              {salaryTakeHomeExampleResultItems.map(({ label, value }) => (
                <div key={label}>
                  <dt>{label}</dt>
                  <dd>{value}</dd>
                </div>
              ))}
            </dl>
          </article>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="exclusion-title">
        <div className={styles.sectionHeading}>
          <h2 id="exclusion-title">자동 반영되지 않는 항목과 예외</h2>
          <p>다음 조건은 현재 계산기가 자동으로 확인하거나 반영하지 않습니다.</p>
        </div>
        <ul className={styles.exclusionList}>
          {salaryTakeHomeExclusions.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      <section className={styles.section} aria-labelledby="faq-title">
        <div className={styles.sectionHeading}>
          <h2 id="faq-title">자주 묻는 질문</h2>
        </div>
        <div className={styles.faqList}>
          {salaryTakeHomeFaqs.map(({ question, answer }) => (
            <details key={question}>
              <summary>{question}</summary>
              <p>{answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="related-title">
        <div className={styles.sectionHeading}>
          <h2 id="related-title">관련 계산기</h2>
        </div>
        <div className={styles.relatedGrid}>
          <a
            className={`${styles.relatedCard} ${styles.relatedLink}`}
            href="/calculators/social-insurance/"
          >
            <h3>2026 4대보험 계산기</h3>
            <p>월급 기준 국민연금, 건강보험, 고용보험 공제액을 계산합니다.</p>
          </a>
          <a
            className={`${styles.relatedCard} ${styles.relatedLink}`}
            href="/calculators/labor-pay/"
          >
            <h3>주휴수당 계산기</h3>
            <p>시급과 소정근로시간 기준 예상 주휴수당을 계산합니다.</p>
          </a>
          <a
            className={`${styles.relatedCard} ${styles.relatedLink}`}
            href="/calculators/severance/"
          >
            <h3>퇴직금 계산기</h3>
            <p>입사일과 퇴직 전 임금으로 예상 퇴직금을 계산합니다.</p>
          </a>
          <a
            className={`${styles.relatedCard} ${styles.relatedLink}`}
            href="/calculators/unemployment/"
          >
            <h3>실업급여 계산기</h3>
            <p>고용보험 가입기간과 임금 기준 예상 구직급여를 계산합니다.</p>
          </a>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="sources-title">
        <div className={styles.sectionHeading}>
          <h2 id="sources-title">공식 출처</h2>
          <p>
            {formatKoreanDate(policy.verifiedAt)}에 아래 공식 기관의 원문을
            확인했습니다.
          </p>
        </div>
        <ul className={styles.sourceList}>
          {salaryTakeHomeSources.map(
            ({ organization, title, criterion, href }) => (
              <li key={href}>
                <div>
                  <strong>{organization}</strong>
                  <span>{criterion}</span>
                </div>
                <a href={href} target="_blank" rel="noopener noreferrer">
                  {title} 원문 보기
                </a>
              </li>
            ),
          )}
        </ul>
      </section>

      <aside className={styles.disclaimer} aria-label="계산 결과 안내">
        계산 결과는 사용자가 입력한 값과 공개된 정책 기준에 따른 예상치입니다.
        실제 공제액은 회사의 급여 규정, 신고 보수월액과 개인별 가입 상태에
        따라 달라질 수 있으며 중도 입사·퇴사, 상여금, 감면·지원과 연말정산은
        별도로 반영될 수 있습니다. 이 결과는 급여명세서, 세무 신고나 기관의
        공식 산정 결과를 대체하지 않으므로 중요한 확인은 회사 급여 담당자나
        관련 기관 자료를 기준으로 해 주세요.
      </aside>
    </div>
  );
}
