import { calculateParentalLeaveBenefit } from "@/lib/calculators/parental-leave/parentalLeave";
import {
  PARENTAL_LEAVE_POLICY_2026,
  PARENTAL_LEAVE_SPECIAL_SOURCE_NAMES,
} from "@/lib/calculators/parental-leave/parentalLeavePolicy";
import { formatWon } from "./parentalLeaveClientUtils";

export interface ParentalLeaveFaq {
  question: string;
  answer: string;
}

export interface ParentalLeaveSource {
  organization: string;
  title: string;
  checkedAt: string;
  href: string;
  criterion: string;
}

export const parentalLeavePolicyCheckedAt = "2026-07-01";

export const parentalLeaveExcludedItems = [
  "부모 양쪽 급여를 합산한 가구 전체 수령액 계산",
  "한부모 특례의 실제 신청 가능 여부 확정 판정",
  "2025년 이전 개시분의 사후지급금과 제도 변경 전후 복합 케이스",
  "사업장별 별도 수당과 회사 내부 규정",
  "고용보험 피보험 단위기간 충족 여부 판정",
  "육아휴직 분할 사용, 복직 여부, 고용센터 심사 결과 판정",
] as const;

export const parentalLeaveCriteriaRows = [
  {
    item: "월 통상임금",
    currentCalculatorBasis: "육아휴직 개시일 기준 월 통상임금을 입력값으로 사용합니다.",
    officialCheck: "임금명세서, 취업규칙, 고용보험 신청 자료 확인",
  },
  {
    item: "1~3개월",
    currentCalculatorBasis: "통상임금 100%, 월 상한 250만원, 하한 70만원을 적용합니다.",
    officialCheck: "고용24 육아휴직급여 안내와 시행령 제95조",
  },
  {
    item: "4~6개월",
    currentCalculatorBasis: "통상임금 100%, 월 상한 200만원, 하한 70만원을 적용합니다.",
    officialCheck: "고용24 육아휴직급여 안내와 시행령 제95조",
  },
  {
    item: "7~12개월",
    currentCalculatorBasis: "통상임금 80%, 월 상한 160만원, 하한 70만원을 적용합니다.",
    officialCheck: "고용24 육아휴직급여 안내와 시행령 제95조",
  },
] as const;

const exampleResponse = calculateParentalLeaveBenefit({
  monthlyOrdinaryWage: 3_000_000,
  leaveMonths: 12,
});

if (!exampleResponse.success) {
  throw new Error("육아휴직급여 계산 예시 입력이 현재 계산 정책을 통과하지 못했습니다.");
}

export const parentalLeaveExample = {
  input: [
    { label: "월 통상임금", value: formatWon(3_000_000) },
    { label: "육아휴직 사용 개월 수", value: "12개월" },
  ],
  result: [
    {
      label: "1~3개월",
      value: "각 2,500,000원",
    },
    {
      label: "4~6개월",
      value: "각 2,000,000원",
    },
    {
      label: "7~12개월",
      value: "각 1,600,000원",
    },
    {
      label: "총 예상 수령액",
      value: formatWon(exampleResponse.data.totalEstimatedAmount),
    },
  ],
} as const;

export const parentalLeaveFaqs: ParentalLeaveFaq[] = [
  {
    question: "육아휴직급여 계산 결과가 확정 지급액인가요?",
    answer:
      "아닙니다. 이 계산기는 2026년 7월 1일 기준 일반 육아휴직급여 구간을 적용한 참고용 예상값입니다. 실제 지급 여부와 금액은 고용보험 가입 기간, 신청 요건, 고용센터 심사 결과에 따라 달라질 수 있습니다.",
  },
  {
    question: "월 통상임금은 어떤 금액을 입력해야 하나요?",
    answer:
      "육아휴직 개시일 기준 통상임금에 가까운 월 금액을 입력합니다. 수당 포함 여부는 개인별 임금 구조와 회사 규정에 따라 달라질 수 있어 공식 신청 자료로 확인해야 합니다.",
  },
  {
    question: "부모 함께 육아휴직제 6+6도 계산되나요?",
    answer:
      "예. 자녀 월령과 배우자 사용 개월 수 등 필요한 조건을 선택하면 6+6 특례 예상액을 계산할 수 있습니다. 실제 적용 여부는 고용센터 심사로 확정됩니다.",
  },
  {
    question: "한부모 육아휴직 특례도 반영되나요?",
    answer:
      "예. 한부모 특례를 선택하면 1~3개월 상한 300만원 구조를 반영합니다. 실제 한부모 해당 여부와 지급 확정은 고용24 또는 고용센터에서 확인해야 합니다.",
  },
  {
    question: "12개월을 넘는 육아휴직도 계산할 수 있나요?",
    answer:
      "일반 모드에서는 1개월부터 12개월까지의 육아휴직급여를 계산합니다. 6+6 또는 한부모 특례 모드를 선택하면 선택한 조건에 맞는 특례 예상액과 일반 기준 구간을 구분해 계산합니다. 12개월 초과, 분할 사용, 복합 제도의 실제 적용 여부와 자격은 자동 판정하지 않으므로 고용24 또는 관할 기관에서 확인해야 합니다.",
  },
  {
    question: "하한액은 언제 적용되나요?",
    answer:
      "구간별 지급률을 적용한 월 급여가 70만원보다 낮으면 하한액 70만원을 예상 지급액으로 표시합니다.",
  },
  {
    question: "고용보험 가입 기간도 자동 판정하나요?",
    answer:
      "아니요. 이 계산기는 금액만 계산하며 피보험 단위기간, 신청 기한, 복직 여부, 심사 결과는 자동 판단하지 않습니다.",
  },
  {
    question: "육아휴직 기간과 시작일을 입력하면 실제 지급액까지 계산되나요?",
    answer:
      "아니요. 입력한 사용 개월 수를 기준으로 월별 예상액을 계산할 뿐, 실제 시작일·종료일, 월 중간 사용에 따른 일할 계산, 분할 사용과 복직 여부는 자동 판단하지 않습니다. 신청 전 고용24 또는 관할 고용센터에서 본인 일정과 지급 기준을 확인해야 합니다.",
  },
  {
    question: "6+6 육아휴직 급여 계산은 어떤 조건을 확인해야 하나요?",
    answer:
      "같은 자녀에 대해 생후 18개월 이내 부모가 모두 육아휴직을 사용하는지와 각 부모의 사용 개월 수 등 특례 조건을 확인해야 합니다. 조건을 충족하지 않으면 일반 기준 예상액으로 표시될 수 있으며, 최종 적용 여부는 고용센터 심사로 확정됩니다.",
  },
] as const;

export const parentalLeaveSources: ParentalLeaveSource[] = [
  {
    organization: "고용24",
    title: "육아휴직급여 정책/제도 안내",
    checkedAt: parentalLeavePolicyCheckedAt,
    href: "https://m.work24.go.kr/cm/c/f/1100/selecSystInfo.do?currentPageNo=1&recordCountPerPage=10&systClId=SC00000251&systId=SI00000402",
    criterion: "일반 육아휴직급여 지급률, 상한액, 특례 안내",
  },
  {
    organization: "국가법령정보센터",
    title: "고용보험법 시행령 제95조 육아휴직 급여",
    checkedAt: parentalLeavePolicyCheckedAt,
    href: "https://www.law.go.kr/LSW/lsSideInfoP.do?docCls=jo&joBrNo=00&joNo=0095&lsiSeq=285831&urlMode=lsScJoRltInfoR",
    criterion: "월별 지급액, 상한액, 하한액 법령 기준",
  },
  {
    organization: "국가법령정보센터",
    title: "고용보험법 시행령 제95조의3 육아휴직 급여 특례",
    checkedAt: parentalLeavePolicyCheckedAt,
    href: "https://www.law.go.kr/LSW//lumLsLinkPop.do?chrClsCd=010202&lspttninfSeq=106251",
    criterion: `${PARENTAL_LEAVE_SPECIAL_SOURCE_NAMES.join(", ")} 기준 특례 구조`,
  },
] as const;

export const parentalLeaveWebApplicationJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "육아휴직급여 계산기",
  description:
    "월 통상임금과 육아휴직 사용 개월 수로 일반 육아휴직급여의 월별 예상액과 총 예상 수령액을 계산하는 참고용 도구입니다.",
  url: "https://gyesanbox.kr/calculators/parental-leave/",
  applicationCategory: "FinanceApplication",
  operatingSystem: "Any",
  browserRequirements: "JavaScript가 지원되는 웹 브라우저",
} as const;

export const parentalLeaveBreadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "홈",
      item: "https://gyesanbox.kr/",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "계산기 목록",
      item: "https://gyesanbox.kr/calculators/",
    },
    {
      "@type": "ListItem",
      position: 3,
      name: "육아휴직급여 계산기",
      item: "https://gyesanbox.kr/calculators/parental-leave/",
    },
  ],
} as const;

export const parentalLeaveFaqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: parentalLeaveFaqs.map(({ question, answer }) => ({
    "@type": "Question",
    name: question,
    acceptedAnswer: {
      "@type": "Answer",
      text: answer,
    },
  })),
} as const;

export const parentalLeaveBasisSummary =
  `계산 기준일은 ${PARENTAL_LEAVE_POLICY_2026.basisDate}입니다. 일반 육아휴직급여는 1~3개월 통상임금 100% 상한 ${formatWon(
    2_500_000,
  )}, 4~6개월 통상임금 100% 상한 ${formatWon(
    2_000_000,
  )}, 7~12개월 통상임금 80% 상한 ${formatWon(
    1_600_000,
  )}을 적용하고, 모든 구간에 월 하한 ${formatWon(700_000)}을 적용합니다.`;

export const parentalLeaveSpecialPolicySummary =
  "부모 함께 육아휴직제 6+6은 같은 자녀, 생후 18개월 이내, 부모 모두 육아휴직 사용 조건을 확인한 뒤 첫 6개월 통상임금 100%와 월별 상한 250만원, 250만원, 300만원, 350만원, 400만원, 450만원을 적용합니다. 한부모 특례는 한부모 해당 여부가 확인된 경우 1~3개월 통상임금 100%, 상한 300만원을 적용하고 4개월차 이후는 일반 기준으로 계산합니다.";

export const parentalLeavePeriodSummary =
  "이 계산기는 입력한 육아휴직 사용 개월 수를 연속 사용한 일반적인 경우로 월별 예상액을 보여줍니다. 실제 휴직 시작일, 분할 사용, 월 중간 시작·종료에 따른 일할 계산과 복직 여부는 자동으로 판단하지 않으므로 신청 자료와 고용24 또는 관할 고용센터 기준을 함께 확인해야 합니다.";
