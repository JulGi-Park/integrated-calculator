import { calculateSalaryTakeHome } from "@/lib/calculators/salary-take-home/salary-take-home";
import { SALARY_TAKE_HOME_POLICY_2026 } from "@/lib/calculators/salary-take-home/policy";
import type { SalaryTakeHomeInput } from "@/lib/calculators/salary-take-home/types";

export interface SalaryTakeHomeContentItem {
  label: string;
  value: string;
}

export interface SalaryTakeHomeFaq {
  question: string;
  answer: string;
}

export interface SalaryTakeHomeSource {
  organization: string;
  title: string;
  criterion: string;
  href: string;
}

const wonFormatter = new Intl.NumberFormat("ko-KR", {
  maximumFractionDigits: 0,
});

function formatWon(value: number): string {
  return `${wonFormatter.format(value)}원`;
}

function formatKoreanDate(value: string): string {
  const [year, month, day] = value.split("-").map(Number);
  return `${year}년 ${month}월 ${day}일`;
}

function formatPercentFromBasisPoints(value: number): string {
  return `${value / 100}%`;
}

export const salaryTakeHomeExampleInput: SalaryTakeHomeInput = {
  annualSalary: 50_000_000,
  monthlyNonTaxableAmount: 200_000,
  dependentCount: 1,
  childCount: 0,
};

const salaryTakeHomeExampleResponse = calculateSalaryTakeHome(
  salaryTakeHomeExampleInput,
);

if (!salaryTakeHomeExampleResponse.success) {
  throw new Error("연봉 계산 예시 입력이 현재 계산 정책을 통과하지 못했습니다.");
}

export const salaryTakeHomeExampleInputItems: SalaryTakeHomeContentItem[] = [
  { label: "연봉", value: formatWon(salaryTakeHomeExampleInput.annualSalary) },
  {
    label: "월 비과세액",
    value: formatWon(salaryTakeHomeExampleInput.monthlyNonTaxableAmount),
  },
  {
    label: "공제대상 가족 수",
    value: `${salaryTakeHomeExampleInput.dependentCount}명`,
  },
  {
    label: "간이세액표상 자녀 수",
    value: `${salaryTakeHomeExampleInput.childCount}명`,
  },
];

const exampleResult = salaryTakeHomeExampleResponse.data;

export const salaryTakeHomeExampleResultItems: SalaryTakeHomeContentItem[] = [
  { label: "월 급여", value: formatWon(exampleResult.monthlyGrossSalary) },
  {
    label: "월 비과세액",
    value: formatWon(salaryTakeHomeExampleInput.monthlyNonTaxableAmount),
  },
  {
    label: "월 과세 급여",
    value: formatWon(exampleResult.monthlyTaxableSalary),
  },
  { label: "국민연금", value: formatWon(exampleResult.nationalPension) },
  { label: "건강보험", value: formatWon(exampleResult.healthInsurance) },
  {
    label: "장기요양보험",
    value: formatWon(exampleResult.longTermCareInsurance),
  },
  {
    label: "고용보험",
    value: formatWon(exampleResult.employmentInsurance),
  },
  { label: "소득세", value: formatWon(exampleResult.incomeTax) },
  { label: "지방소득세", value: formatWon(exampleResult.localIncomeTax) },
  {
    label: "월 공제 합계",
    value: formatWon(exampleResult.totalMonthlyDeductions),
  },
  {
    label: "월 예상 실수령액",
    value: formatWon(exampleResult.estimatedMonthlyTakeHome),
  },
  {
    label: "연간 예상 실수령액",
    value: formatWon(exampleResult.estimatedAnnualTakeHome),
  },
];

const policy = SALARY_TAKE_HOME_POLICY_2026;
const employeeHealthInsuranceRate =
  policy.healthInsurance.totalRateBasisPoints /
  policy.healthInsurance.employeeShareDenominator;

export const salaryTakeHomeCalculationCriteria = [
  {
    title: "월 급여",
    description:
      "퇴직금을 제외한 연봉을 12개월로 나누고, 원 미만이 생기면 버립니다.",
  },
  {
    title: "월 과세 급여",
    description:
      "월 급여에서 입력한 월 비과세액을 차감합니다. 이 값은 보험료와 소득세 계산의 기초가 되며, 국민연금에는 별도의 기준소득월액 상·하한과 1,000원 단위 처리가 적용됩니다.",
  },
  {
    title: "국민연금",
    description: `사업장가입자 근로자 부담률 ${formatPercentFromBasisPoints(policy.nationalPension.employeeRateBasisPoints)}를 적용합니다. 기준소득월액은 1,000원 미만을 버린 뒤 ${formatWon(policy.nationalPension.standardMonthlyIncomeMinimum)}~${formatWon(policy.nationalPension.standardMonthlyIncomeMaximum)} 범위로 제한하고 보험료의 10원 미만을 버립니다.`,
  },
  {
    title: "건강보험",
    description: `직장가입자 총 보험료율 ${formatPercentFromBasisPoints(policy.healthInsurance.totalRateBasisPoints)}의 절반인 근로자 부담분 ${formatPercentFromBasisPoints(employeeHealthInsuranceRate)}를 월 과세 급여에 적용하고 원 미만을 버립니다.`,
  },
  {
    title: "장기요양보험",
    description: `건강보험과 구분되는 공제입니다. 근로자 건강보험료 × 소득 대비 장기요양보험료율 0.9448% ÷ 건강보험료율 7.19%로 계산하고 원 미만을 버립니다.`,
  },
  {
    title: "고용보험",
    description: `월 과세 급여에 근로자 부담률 ${formatPercentFromBasisPoints(policy.employmentInsurance.employeeRateBasisPoints)}를 적용하고 원 미만을 버립니다. 사업주 부담분과 산재보험은 제외합니다.`,
  },
  {
    title: "근로소득세",
    description: `${formatKoreanDate(policy.incomeTax.tableEffectiveFrom)} 개정 근로소득 간이세액표에서 월 과세 급여, 본인을 포함한 공제대상 가족 수, 간이세액표상 자녀 수를 반영한 100% 원천징수 기준 금액을 계산하고 10원 미만을 버립니다.`,
  },
  {
    title: "지방소득세",
    description: `산출된 소득세의 ${policy.localIncomeTax.percentageOfIncomeTax}%를 계산하고 10원 미만을 버립니다.`,
  },
  {
    title: "월 공제 합계",
    description:
      "국민연금, 건강보험, 장기요양보험, 고용보험, 소득세, 지방소득세의 합계입니다.",
  },
  {
    title: "월 예상 실수령액",
    description: "월 급여에서 월 공제 합계를 차감한 예상 금액입니다.",
  },
  {
    title: "연간 예상 실수령액",
    description:
      "월 예상 실수령액을 12배한 값입니다. 월별 상여나 변동 급여를 반영한 실제 연간 지급액은 아닙니다.",
  },
] as const;

export const salaryTakeHomeExclusions = [
  "퇴직금",
  "비정기 상여금",
  "성과급",
  "연장·야간·휴일근로수당",
  "회사별 추가 공제",
  "노조비",
  "회사가 별도 공제하는 식대",
  "사내대출 상환",
  "연말정산 환급·추가 납부",
  "중도 입사·퇴사",
  "휴직",
  "월별 급여 변동",
  "일용근로자",
  "사업소득자·프리랜서",
  "보험료 감면",
  "두루누리 등 보험료 지원",
  "특수한 가입 상태",
  "실제 신고 보수월액과 입력값의 차이",
  "회사별 원천징수 선택 비율 차이",
] as const;

export const salaryTakeHomeFaqs: SalaryTakeHomeFaq[] = [
  {
    question: "연봉에 퇴직금이 포함되나요?",
    answer:
      "현재 계산기는 퇴직금을 제외한 연봉을 기준으로 합니다. 제시받은 연봉에 퇴직금이 포함돼 있다면 퇴직금을 제외한 세전 연봉을 입력해 주세요.",
  },
  {
    question: "공제대상 가족 수에는 본인도 포함하나요?",
    answer:
      "네. 공제대상 가족 수에는 근로자 본인을 포함합니다. 기본값 1명은 공제대상 가족이 본인만 있는 경우입니다.",
  },
  {
    question: "자녀 수는 어떤 기준으로 입력하나요?",
    answer:
      "간이세액표상 자녀 수는 공제대상 가족 중 8세 이상 20세 이하이며 관련 소득 요건을 충족하는 자녀 수입니다. 모든 미성년 자녀 수를 그대로 입력하는 항목은 아닙니다.",
  },
  {
    question: "비과세액은 얼마를 입력해야 하나요?",
    answer:
      "이 입력란은 월 비과세액을 받습니다. 매월 급여에 실제 포함되어 과세 대상에서 제외되는 금액을 급여명세서나 근로계약서에서 확인해 입력하세요. 식대·차량보조금 등 모든 수당이 자동으로 비과세가 되는 것은 아니며, 비과세액을 입력했다고 해서 모든 사회보험료와 세금의 기준이 같은 금액만큼 줄어든다고 단정할 수는 없습니다.",
  },
  {
    question: "실제 급여명세서와 결과가 다른 이유는 무엇인가요?",
    answer:
      "실제 신고 보수월액, 회사별 급여 처리, 상여금과 변동 수당, 추가 공제, 보험료 정산, 원천징수 방식, 개인별 감면과 지원에 따라 차이가 생길 수 있습니다.",
  },
  {
    question: "상여금과 성과급도 계산되나요?",
    answer:
      "아니요. 이번 계산은 입력한 연봉을 12개월로 나눈 일반 월 급여를 기준으로 하며 비정기 상여금과 성과급은 별도로 반영하지 않습니다.",
  },
  {
    question: "기준소득월액과 실제 월급은 왜 다른가요?",
    answer:
      "국민연금의 기준소득월액은 보험료와 급여 산정을 위한 신고 기준이고, 실수령액은 월 급여에서 사회보험료와 세금 등을 차감한 뒤 남는 금액입니다. 따라서 기준소득월액에서 공제액을 바로 빼서 실수령액을 구하는 구조가 아닙니다. 건강보험의 보수월액과 고용보험의 보수도 별도 신고·정산 구조가 있을 수 있으며, 비과세 항목·상여금·소급분·회사 신고 시점에 따라 실제 급여명세서와 달라질 수 있습니다.",
  },
  {
    question: "월급 공제액에는 어떤 항목이 포함되나요?",
    answer:
      "근로자 기준 월 공제 합계에는 국민연금, 건강보험, 장기요양보험, 고용보험, 소득세, 지방소득세가 포함됩니다. 사업주 부담분과 산재보험료는 이 결과에 포함하지 않습니다.",
  },
  {
    question: "4대보험 계산기와 연봉 실수령액 계산기는 무엇이 다른가요?",
    answer:
      "연봉 실수령액 계산기는 연봉을 12개월로 나눈 월 급여에서 세금과 근로자 사회보험료를 차감한 예상 금액을 보여 줍니다. 보험별 근로자·사업주 부담액과 기준소득월액을 자세히 비교하려면 관련 계산기의 2026 4대보험 계산기를 이용하세요.",
  },
  {
    question: "국민연금 상한을 넘는 연봉은 어떻게 계산되나요?",
    answer: `국민연금은 월 소득 전체에 계속 비례하지 않고 현재 적용 중인 기준소득월액 상한 ${formatWon(policy.nationalPension.standardMonthlyIncomeMaximum)}까지만 산정 기준에 반영합니다. 이 상한은 ${formatKoreanDate(policy.nationalPension.ceilingEffectiveFrom)}부터 ${formatKoreanDate(policy.nationalPension.ceilingEffectiveTo)}까지의 기준입니다.`,
  },
  {
    question: "현재 국민연금 기준소득월액 상·하한은 언제까지 적용되나요?",
    answer: `현재 계산기는 ${formatKoreanDate(policy.verifiedAt)}에 확인한 기준을 사용합니다. 기준소득월액 하한과 상한은 ${formatKoreanDate(policy.nationalPension.ceilingEffectiveFrom)}부터 ${formatKoreanDate(policy.nationalPension.ceilingEffectiveTo)}까지 적용됩니다. 이후 기준은 국민연금공단의 최신 안내를 다시 확인해야 합니다.`,
  },
];

export const salaryTakeHomeSources: SalaryTakeHomeSource[] = [
  {
    organization: "국민연금공단",
    title: "연금보험료 금액 및 보험료율",
    criterion: "2026년 기준소득월액 상한·하한, 적용 기간과 사업장가입자 근로자 부담률",
    href: "https://www.nps.or.kr/pnsinfo/ntpsklg/getOHAF0038M0.do?menuId=MN24001113&tab=tab5",
  },
  {
    organization: "국민건강보험공단",
    title: "직장가입자 보수월액변경신청서",
    criterion: "국민연금 기준소득월액, 건강보험 보수월액, 고용보험 월평균보수의 구분과 변경·정산 구조",
    href: "https://www.nhis.or.kr/static/html/wbdb/f/wbdbf0501.html",
  },
  {
    organization: "고용노동부",
    title: "고용보험기금 소개",
    criterion: "고용보험의 근로자·사업주 부담 구분과 월별 보험료 산정에 쓰이는 보수 안내",
    href: "https://www.moel.go.kr/info/astmgmt/employ/employList.do",
  },
  {
    organization: "국가법령정보센터",
    title: "고용보험 및 산업재해보상보험의 보험료징수 등에 관한 법률 시행령",
    criterion: "고용보험 근로자 부담 기준과 산재보험 제외",
    href: "https://www.law.go.kr/법령/고용보험및산업재해보상보험의보험료징수등에관한법률시행령",
  },
  {
    organization: "국세청",
    title: "근로소득 간이세액표 안내",
    criterion: "2026년 근로소득 간이세액표와 가족·자녀 기준",
    href: "https://www.nts.go.kr/nts/cm/cntnts/cntntsView.do?cntntsId=7862&mi=6426",
  },
  {
    organization: "국가법령정보센터",
    title: "소득세법 시행령 별표 2",
    criterion: "근로소득 간이세액표 법적 근거",
    href: "https://www.law.go.kr/법령/소득세법시행령",
  },
  {
    organization: "국가법령정보센터",
    title: "지방세법",
    criterion: "지방소득세 계산 기준",
    href: "https://www.law.go.kr/법령/지방세법",
  },
];

export const salaryTakeHomeWebApplicationJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "연봉 실수령액 계산기",
  description:
    "연봉을 월급으로 환산하고 월 비과세액과 가족·자녀 수를 입력해 세금과 사회보험료 공제 후 예상 월·연 실수령액을 확인합니다.",
  applicationCategory: "FinanceApplication",
  operatingSystem: "Any",
  browserRequirements: "JavaScript가 지원되는 웹 브라우저",
};

export const salaryTakeHomeBreadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "홈",
      item: "https://gyesanbox.kr/",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "계산기 목록",
      item: "https://gyesanbox.kr/calculators/",
    },
    {
      "@type": "ListItem",
      position: 3,
      name: "연봉 실수령액 계산기",
      item: "https://gyesanbox.kr/calculators/salary/",
    },
  ],
};

export const salaryTakeHomeFaqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: salaryTakeHomeFaqs.map(({ question, answer }) => ({
    "@type": "Question",
    name: question,
    acceptedAnswer: {
      "@type": "Answer",
      text: answer,
    },
  })),
};
