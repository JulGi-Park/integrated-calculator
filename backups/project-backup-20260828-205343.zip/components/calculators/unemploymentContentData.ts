import { UNEMPLOYMENT_POLICY_2026 } from "@/lib/calculators/unemployment/policy";
import { calculateUnemploymentBenefit } from "@/lib/calculators/unemployment/unemployment";
import type { UnemploymentInput } from "@/lib/calculators/unemployment/types";

export interface UnemploymentTableRow {
  label: string;
  importance: string;
  calculatorCoverage: string;
  additionalCheck: string;
}

export interface UnemploymentCriteriaRow {
  item: string;
  currentCalculatorBasis: string;
  officialCheck: string;
}

export interface UnemploymentFaq {
  question: string;
  answer: string;
}

export interface UnemploymentSource {
  organization: string;
  title: string;
  checkedAt: string;
  href: string;
  criterion: string;
}

export interface UnemploymentRelatedCalculator {
  href: "/calculators/severance/" | "/calculators/salary/" | "/calculators/loan/" | "/calculators/seller-margin/";
  title: string;
  description: string;
}

const wonFormatter = new Intl.NumberFormat("ko-KR", {
  maximumFractionDigits: 0,
});

function formatWon(value: number): string {
  return `${wonFormatter.format(value)}원`;
}

function formatKoreanDate(value: string): string {
  const [year, month, day] = value.split("-").map(Number);
  return `${year}년 ${month}월 ${day}일`;
}

export const unemploymentPolicyCheckedAt = "2026-06-25";
export const unemploymentUpperBasisDailyWage = 113_500;
export const unemploymentMinimumWage2026 = 10_320;
export const unemploymentStandardDailyHours = 8;
export const unemploymentMinimumWageBenefitRate = 80;
export const unemploymentScheduledHoursLowerLimits = [
  { hours: "4시간 이하", amount: 33_024 },
  { hours: "5시간", amount: 41_280 },
  { hours: "6시간", amount: 49_536 },
  { hours: "7시간", amount: 57_792 },
  { hours: "8시간 이상", amount: 66_048 },
] as const;

export const unemploymentExampleInput: UnemploymentInput = {
  wageInputType: "monthlyWage",
  wageAmount: 3_300_000,
  scheduledDailyHours: 8,
  insuredMonths: 36,
  ageGroup: "under50",
  leavingReason: "involuntary",
};

const unemploymentExampleResponse =
  calculateUnemploymentBenefit(unemploymentExampleInput);

if (!unemploymentExampleResponse.success) {
  throw new Error("실업급여 계산 예시 입력이 현재 계산 정책을 통과하지 못했습니다.");
}

const unemploymentExampleResult = unemploymentExampleResponse.data;

export const unemploymentExampleInputItems = [
  { label: "임금 입력 방식", value: "월급 기준 간편 입력" },
  { label: "월급", value: formatWon(unemploymentExampleInput.wageAmount) },
  { label: "1일 소정근로시간", value: "8시간 이상" },
  { label: "고용보험 가입기간", value: "36개월" },
  { label: "나이 구간", value: "50세 미만" },
  { label: "퇴직 사유", value: "비자발적 퇴사" },
] as const;

export const unemploymentExampleResultItems = [
  {
    label: "추정 1일 평균임금",
    value: formatWon(unemploymentExampleResult.estimatedAverageDailyWage),
  },
  {
    label: "계산 전 기준 급여액",
    value: formatWon(unemploymentExampleResult.baseDailyBenefit),
  },
  {
    label: "적용 하한액",
    value: formatWon(unemploymentExampleResult.dailyBenefitLowerLimit),
  },
  {
    label: "1일 예상 구직급여액",
    value: formatWon(unemploymentExampleResult.dailyBenefitAmount),
  },
  {
    label: "예상 소정급여일수",
    value: `${unemploymentExampleResult.prescribedBenefitDays}일`,
  },
  {
    label: "예상 총 지급액",
    value: formatWon(unemploymentExampleResult.estimatedTotalBenefit),
  },
] as const;

export const unemploymentInterpretationCards = [
  {
    title: "1일 구직급여액",
    description:
      "퇴직 전 평균임금 또는 입력한 1일 평균임금에 60%를 적용한 뒤, 2026년 공식 상한액과 하한액 범위로 조정한 하루 예상 금액입니다.",
  },
  {
    title: "상한액·하한액",
    description:
      "고용보험법 시행령 제68조의 113,500원은 급여기초 임금일액의 상한이며, 고용보험법 제46조의 60%를 적용한 68,100원이 2026년 1일 구직급여 상한액입니다. 하한액은 제68조가 아니라 2026년 최저임금 10,320원 × 80% × 선택한 1일 소정근로시간으로 계산하며, 8시간 이상 하한액은 66,048원입니다.",
  },
  {
    title: "소정급여일수",
    description:
      "고용보험 가입기간과 퇴직 당시 나이 구간에 따라 정해지는 예상 지급일수입니다. 실제 지급은 수급기간과 실업인정 절차의 영향을 받습니다.",
  },
  {
    title: "예상 총 지급액",
    description:
      "1일 예상 구직급여액에 예상 소정급여일수를 곱한 참고용 금액입니다. 이직확인서, 퇴직 사유와 고용센터 판단에 따라 실제 지급 여부와 시점은 달라질 수 있습니다.",
  },
] as const;

export const unemploymentDirectAnswerItems = [
  {
    title: "하루 상한액",
    description:
      "2026년 1일 구직급여 상한액은 68,100원입니다. 고용보험법 시행령 제68조가 정한 급여기초 임금일액 상한 113,500원에 고용보험법 제46조의 60%를 적용한 값이며, 113,500원 자체가 실제 하루 구직급여 상한액은 아닙니다.",
  },
  {
    title: "하루 하한액",
    description:
      "하한액은 고용보험법 시행령 제68조의 113,500원에서 계산하지 않습니다. 2026년 최저임금 10,320원 × 80% × 이직 전 인정 1일 소정근로시간으로 계산하며, 4시간 이하는 33,024원, 5시간은 41,280원, 6시간은 49,536원, 7시간은 57,792원, 8시간 이상은 66,048원입니다. 실제 인정 시간은 근로계약·이직확인서와 고용센터 확인이 필요합니다.",
  },
  {
    title: "지급일수",
    description:
      "소정급여일수는 고용보험 가입기간과 이직 당시 나이 구간에 따라 120일부터 270일까지 예상합니다.",
  },
  {
    title: "입력 기준",
    description:
      "월급 입력은 월급 ÷ 30의 간편 추정입니다. 퇴직 전 1일 평균임금을 알면 직접 입력이 더 적합하며, 두 방식 모두 근로계약상 1일 소정근로시간을 별도로 선택합니다.",
  },
] as const;

export const unemploymentChecklist = [
  "이직일 이전 기준기간의 피보험 단위기간이 180일 이상인지 확인합니다.",
  "회사에서 고용보험 피보험자격 상실 신고서와 이직확인서를 제출했는지 확인합니다.",
  "퇴직 사유가 수급자격 제한 사유에 해당하지 않는지 확인합니다.",
  "워크넷 또는 고용24 구직 등록과 수급자격 신청자 교육 절차를 확인합니다.",
  "실업인정일마다 재취업 활동을 증명할 준비가 되어 있는지 확인합니다.",
  "자발적 퇴사라면 정당한 이직 사유와 증빙 가능성을 고용센터에 확인합니다.",
] as const;

export const unemploymentExcludedItems = [
  "개별 사업장의 이직 사유 판단과 증빙 심사",
  "피보험 단위기간 180일의 일 단위 정밀 계산",
  "대기기간, 조기재취업수당, 취업촉진수당과 부정수급 판단",
  "실업인정일별 실제 지급일과 지급 보류 여부",
  "세부 법령 개정이나 고시 변경의 실시간 반영",
  "이직확인서상 1일 소정근로시간의 실제 인정과 시간 외·휴게시간 반영 여부",
  "고용센터 심사 결과와 행정 처분 판단",
] as const;

export const unemploymentQuickCheckRows: UnemploymentTableRow[] = [
  {
    label: "피보험 단위기간",
    importance: "수급요건의 핵심 기준입니다.",
    calculatorCoverage: "가입 개월 수로 간단히 추정합니다.",
    additionalCheck: "180일 충족 여부는 공식 이력으로 확인 필요",
  },
  {
    label: "퇴직 사유",
    importance: "수급자격 제한 여부에 영향을 줍니다.",
    calculatorCoverage: "선택한 사유별 안내 상태를 표시합니다.",
    additionalCheck: "이직확인서와 증빙 확인 필요",
  },
  {
    label: "1일 평균임금",
    importance: "1일 구직급여액의 출발점입니다.",
    calculatorCoverage: "월급 ÷ 30 또는 직접 입력을 지원합니다.",
    additionalCheck: "퇴직 전 3개월 임금자료 확인 필요",
  },
  {
    label: "1일 소정근로시간",
    importance: "시간별 구직급여 하한액을 결정합니다.",
    calculatorCoverage: "4시간 이하·5·6·7·8시간 이상 중 선택합니다.",
    additionalCheck: "이직확인서와 고용센터 인정 시간 확인 필요",
  },
  {
    label: "나이 구간",
    importance: "소정급여일수 표의 구간을 결정합니다.",
    calculatorCoverage: "50세 미만, 50세 이상 및 장애인 구간을 반영합니다.",
    additionalCheck: "이직 당시 기준 확인 필요",
  },
  {
    label: "실업인정",
    importance: "실제 지급이 이어지는 절차입니다.",
    calculatorCoverage: "금액 계산에는 직접 반영하지 않습니다.",
    additionalCheck: "고용센터 지정일과 재취업 활동 확인 필요",
  },
] as const;

export const unemploymentCriteriaRows: UnemploymentCriteriaRow[] = [
  {
    item: "1일 평균임금",
    currentCalculatorBasis: "월급 입력 시 30으로 나누어 추정하거나 직접 입력값을 사용합니다.",
    officialCheck: "퇴직 전 평균임금 자료로 재확인",
  },
  {
    item: "60% 계산",
    currentCalculatorBasis: "추정 1일 평균임금에 60%를 곱합니다.",
    officialCheck: "고용보험법 제46조 구직급여일액 산식",
  },
  {
    item: "상한액",
    currentCalculatorBasis: `급여기초 임금일액 상한 ${formatWon(unemploymentUpperBasisDailyWage)} × 60% = ${formatWon(UNEMPLOYMENT_POLICY_2026.dailyBenefitUpperLimit)}을 적용합니다.`,
    officialCheck: "고용보험법 시행령 제68조의 기초일액 상한과 제46조의 60% 산식",
  },
  {
    item: "하한액",
    currentCalculatorBasis: `2026년 최저임금 ${formatWon(unemploymentMinimumWage2026)} × ${unemploymentMinimumWageBenefitRate}% × 선택한 1일 소정근로시간을 적용합니다. 8시간 이상은 ${formatWon(UNEMPLOYMENT_POLICY_2026.dailyBenefitLowerLimit)}입니다.`,
    officialCheck: "고용보험법 제45조·제46조, 최저임금 고시와 인정 소정근로시간",
  },
  {
    item: "소정근로시간",
    currentCalculatorBasis: "4시간 이하·5시간·6시간·7시간·8시간 이상 구간별 하한액을 적용합니다.",
    officialCheck: "이직 전 근로계약·이직확인서와 고용센터 인정 시간 확인",
  },
  {
    item: "고용보험 가입기간",
    currentCalculatorBasis: "6개월 미만은 계산 제한으로 안내하고, 개월 수별 소정급여일수를 추정합니다.",
    officialCheck: "피보험 단위기간 180일과 수급 이력 확인",
  },
  {
    item: "나이 구간",
    currentCalculatorBasis: "50세 미만과 50세 이상 및 장애인 구간을 나눕니다.",
    officialCheck: "이직 당시 연령 기준 확인",
  },
  {
    item: "퇴직 사유",
    currentCalculatorBasis: "비자발, 계약만료, 권고사직, 자발, 예외 검토 등 안내 상태만 표시합니다.",
    officialCheck: "이직확인서와 고용센터 판단 확인",
  },
  {
    item: "이직확인서·실업인정",
    currentCalculatorBasis: "금액 산식에는 포함하지 않고 절차 안내로 제공합니다.",
    officialCheck: "고용24 민원현황과 실업인정 절차 확인",
  },
] as const;

export const unemploymentFaqs: UnemploymentFaq[] = [
  {
    question: "실업급여 계산기는 실제 지급액과 같은가요?",
    answer:
      "아닙니다. 이 계산기는 입력값과 현재 계산기 적용 기준으로 예상 금액을 보여주는 참고용 도구입니다. 실제 지급 여부와 금액은 고용보험 이력, 퇴직 사유, 이직확인서와 실업인정 절차에 따라 달라질 수 있습니다.",
  },
  {
    question: "월급만 알아도 실업급여를 계산할 수 있나요?",
    answer:
      "간편 추정은 가능합니다. 다만 월급 기준은 월급을 30으로 나누어 1일 평균임금을 추정하므로, 퇴직 전 3개월 평균임금을 알고 있다면 1일 평균임금 직접 입력이 더 적합합니다.",
  },
  {
    question: "2026년 실업급여 하루 상한액과 하한액은 얼마인가요?",
    answer:
      "현재 계산기는 2026년 1일 상한액 68,100원을 사용합니다. 이는 시행령 제68조의 급여기초 임금일액 상한 113,500원에 고용보험법 제46조의 60%를 적용한 값입니다. 하한액은 제68조가 아니라 최저임금 10,320원 × 80% × 이직 전 인정 1일 소정근로시간으로 계산해 4시간 이하 33,024원, 5시간 41,280원, 6시간 49,536원, 7시간 57,792원, 8시간 이상 66,048원입니다.",
  },
  {
    question: "급여기초 임금일액 113,500원은 실제로 받는 하루 실업급여인가요?",
    answer:
      "아닙니다. 고용보험법 시행령 제68조의 113,500원은 구직급여 산정의 기초가 되는 임금일액 상한입니다. 고용보험법 제46조에 따라 여기에 60%를 적용한 68,100원이 현재 계산기의 하루 구직급여 상한액입니다. 하한액은 이 금액에서 계산하지 않고 최저임금·80%·인정 소정근로시간을 따로 적용합니다.",
  },
  {
    question: "자발적 퇴사도 실업급여를 받을 수 있나요?",
    answer:
      "자발적 퇴사는 일반적으로 제한될 수 있습니다. 다만 임금체불, 질병, 통근 곤란 등 정당한 이직 사유가 인정될 가능성이 있는 경우에는 객관적 증빙을 갖추어 고용센터 확인을 받아야 합니다.",
  },
  {
    question: "실업급여 지급일수는 어떻게 계산하나요?",
    answer:
      "현재 계산기는 고용보험 가입기간과 이직 당시 나이 구간을 조합해 소정급여일수를 120일부터 270일까지 예상합니다. 가입 개월 수는 간편 입력값이므로, 실제 피보험 단위기간 180일 충족 여부와 개인별 적용일수는 공식 이력으로 확인해야 합니다.",
  },
  {
    question: "월급이 80만원이면 하한액이 바로 적용되나요?",
    answer:
      "아닙니다. 월급 80만원, 가입기간 36개월, 50세 미만, 비자발적 퇴사 입력은 월급 ÷ 30의 간편 추정값 26,667원에 60%를 적용한 약 16,000원보다 시간별 하한액이 높아 하한을 적용합니다. 다만 1일 소정근로시간에 따라 4시간 이하는 33,024원, 6시간은 49,536원, 8시간 이상은 66,048원으로 결과가 달라집니다. 180일 기준 총액도 각각 5,944,320원, 8,916,480원, 11,888,640원입니다. 실제 인정 시간과 지급액은 이직확인서와 고용센터에서 확인해야 합니다.",
  },
  {
    question: "이직확인서와 실업인정은 계산 결과와 어떤 관계가 있나요?",
    answer:
      "계산 결과는 예상 금액과 일수를 보여줍니다. 실제 지급을 위해서는 이직확인서의 퇴직 사실·사유 확인과 지정된 실업인정일의 재취업 활동 등 요건 확인이 이어져야 합니다.",
  },
] as const;

export const unemploymentSources: UnemploymentSource[] = [
  {
    organization: "고용노동부 고객상담센터",
    title: "구직급여일액 FAQ(시간별 하한액 구조 참고)",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://1350.moel.go.kr/home/hp/data/faqView.do?faq_idx=1000001176",
    criterion: "시간별 하한액 구조와 4시간 이하 처리 참고. 2022·2023년 금액은 2026년 수치 근거로 사용하지 않음",
  },
  {
    organization: "국가법령정보센터",
    title: "고용보험법 시행규칙 제101조·별표 2",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://www.law.go.kr/법령/고용보험법시행규칙",
    criterion: "자발적 이직의 수급자격 제한 및 정당한 이직 사유 기준",
  },
  {
    organization: "고용24",
    title: "실업급여(상용직) 정책/제도 안내",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://m.work24.go.kr/cm/c/f/1100/selecSystInfo.do?systClId=SC00000254&systCnntId=&systId=SI00000411",
    criterion: "신청 절차, 이직확인서, 실업인정 흐름",
  },
  {
    organization: "고용노동부",
    title: "고용보험법 시행령 등 일부개정령안 국무회의 심의",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://www.moel.go.kr/news/enews/report/enewsView.do?news_seq=18736",
    criterion: "2026년 구직급여 상한액 68,100원 인상과 급여기초 임금일액 상한 113,500원",
  },
  {
    organization: "국가법령정보센터",
    title: "고용보험법 제45조 급여의 기초가 되는 임금일액",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://www.law.go.kr/LSW//lsLawLinkInfo.do?chrClsCd=010202&lsId=001761&lsJoLnkSeq=1000770542&print=print",
    criterion: "기초일액 산정, 최저기초일액, 대통령령 상한 근거",
  },
  {
    organization: "국가법령정보센터",
    title: "고용보험법 제46조 구직급여일액",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://www.law.go.kr/LSW//lsLawLinkInfo.do?chrClsCd=010202&lsId=001761&lsJoLnkSeq=1000770549&print=print",
    criterion: "기초일액 60%와 최저기초일액 80% 산식",
  },
  {
    organization: "국가법령정보센터",
    title: "고용보험법 시행령 제68조 급여기초 임금일액의 상한액",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://www.law.go.kr/lsLinkProc.do?chrClsCd=010202&datClsCd=010102&gubun=admRul&joNo=006800000&lsId=41988&lsNm=%EA%B3%A0%EC%9A%A9%EB%B3%B4%ED%97%98%EB%B2%95%EC%8B%9C%ED%96%89%EB%A0%B9&mode=10",
    criterion: "급여기초 임금일액 상한 113,500원",
  },
  {
    organization: "찾기쉬운 생활법령정보",
    title: "구직급여 수급액 및 기초일액의 상·하한",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://www.easylaw.go.kr/CSP/CnpClsMain.laf?ccfNo=2&cciNo=3&cnpClsNo=2&csmSeq=722&popMenu=ov",
    criterion: "2026년 113,500원·68,100원 관계, 최저임금 하한 구조와 10,320원 확인",
  },
  {
    organization: "국가법령정보센터",
    title: "고용보험법 제40조 구직급여의 수급 요건",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://www.law.go.kr/lsLawLinkInfo.do?chrClsCd=010202&lsJoLnkSeq=900111129",
    criterion: "피보험 단위기간 180일, 재취업 노력, 이직 사유 요건",
  },
  {
    organization: "고용노동부",
    title: "2026년 적용 최저임금 고시",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://www.moel.go.kr/info/lawinfo/instruction/view.do?bbs_seq=20250800121",
    criterion: "2026년 시간급 최저임금 고시 확인",
  },
  {
    organization: "최저임금위원회",
    title: "2026년 적용 최저임금 고시",
    checkedAt: unemploymentPolicyCheckedAt,
    href: "https://www.minimumwage.go.kr/customer/notice/view.do?bultnId=4657",
    criterion: "2026년 시간급 10,320원 안내",
  },
] as const;

export const unemploymentRelatedCalculators: UnemploymentRelatedCalculator[] = [
  {
    href: "/calculators/severance/",
    title: "퇴직금 계산기",
    description: "입사일과 퇴직 전 임금으로 예상 퇴직금을 계산합니다.",
  },
  {
    href: "/calculators/salary/",
    title: "연봉 실수령액 계산기",
    description: "4대보험과 간이세액표 기준 실수령액을 확인합니다.",
  },
  {
    href: "/calculators/loan/",
    title: "대출 이자 계산기",
    description: "상환방식별 월 납입액과 총이자를 비교합니다.",
  },
  {
    href: "/calculators/seller-margin/",
    title: "판매자 마진 계산기",
    description: "판매가, 원가, 수수료 기준 순이익과 마진율을 계산합니다.",
  },
] as const;

export const unemploymentWebApplicationJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "실업급여 계산기",
  description:
    "월급 또는 1일 평균임금으로 구직급여 상한액·하한액 적용 여부, 수급기간과 예상 총액을 계산하는 참고용 도구입니다.",
  url: "/calculators/unemployment/",
  applicationCategory: "FinanceApplication",
  operatingSystem: "Any",
  browserRequirements: "JavaScript가 지원되는 웹 브라우저",
} as const;

export const unemploymentBreadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "홈",
      item: "https://gyesanbox.kr/",
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "계산기 목록",
      item: "https://gyesanbox.kr/calculators/",
    },
    {
      "@type": "ListItem",
      position: 3,
      name: "실업급여 계산기",
      item: "https://gyesanbox.kr/calculators/unemployment/",
    },
  ],
} as const;

export const unemploymentFaqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: unemploymentFaqs.map(({ question, answer }) => ({
    "@type": "Question",
    name: question,
    acceptedAnswer: {
      "@type": "Answer",
      text: answer,
    },
  })),
} as const;

export const unemploymentBasisSummary =
  `현재 계산기 기준일은 ${formatKoreanDate(
    UNEMPLOYMENT_POLICY_2026.basisDate,
  )}이며, 2026년 공식 기준인 상한액 ${formatWon(
    UNEMPLOYMENT_POLICY_2026.dailyBenefitUpperLimit,
  )}과 선택한 1일 소정근로시간별 하한액을 계산 상수로 사용합니다. 상한액 산식은 ${formatWon(
    unemploymentUpperBasisDailyWage,
  )} × 60% = ${formatWon(
    UNEMPLOYMENT_POLICY_2026.dailyBenefitUpperLimit,
  )}, 하한액 산식은 ${formatWon(
    unemploymentMinimumWage2026,
  )} × ${unemploymentMinimumWageBenefitRate}% × 선택한 소정근로시간입니다. 8시간 이상 기준은 ${formatWon(
    UNEMPLOYMENT_POLICY_2026.dailyBenefitLowerLimit,
  )}입니다.`;
