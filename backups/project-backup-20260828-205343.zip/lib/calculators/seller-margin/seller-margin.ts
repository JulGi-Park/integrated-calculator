/**
 * 주문 1건의 세전 예상 손익 계산 엔진입니다.
 *
 * 부가가치세, 소득세, 법인세, 원천징수, 반품·환불, 쿠폰 분담,
 * 플랫폼별 자동 수수료·반올림 정책과 손익분기 판매가는 계산하지 않습니다.
 * 모든 비용과 수수료율은 사용자가 직접 입력한 값을 사용합니다.
 */

export interface SellerMarginInput {
  /** 상품 판매단가 (원) */
  unitPrice: number;
  /** 판매수량 (양의 정수) */
  quantity: number;
  /** 판매자 부담 할인금액 (원) */
  sellerDiscount: number;
  /** 고객에게 받은 배송비 (원) */
  customerShippingFee: number;
  /** 상품 1개당 원가 (원) */
  unitProductCost: number;
  /** 플랫폼 수수료율 (%) */
  platformFeeRate: number;
  /** 결제 수수료율 (%) */
  paymentFeeRate: number;
  /** 판매자 부담 배송비 (원) */
  sellerShippingCost: number;
  /** 주문에 배분된 광고비 (원) */
  allocatedAdCost: number;
  /** 기타 비용 (원) */
  otherCost: number;
}

export interface SellerMarginResult {
  /** 상품 판매금액 (원, 정수) */
  productSalesAmount: number;
  /** 결제금액 (원, 정수) */
  paymentAmount: number;
  /** 플랫폼 수수료 (원, 정수) */
  platformFee: number;
  /** 결제 수수료 (원, 정수) */
  paymentFee: number;
  /** 총수수료 (원, 정수) */
  totalFees: number;
  /** 예상 정산금액 (원, 정수) */
  estimatedSettlement: number;
  /** 총비용 (원, 정수) */
  totalCosts: number;
  /** 예상 순이익 (원, 정수) */
  estimatedNetProfit: number;
  /** 순이익률 (%, 소수점 둘째 자리) */
  netProfitMarginRate: number;
  /** 원가율 (%, 소수점 둘째 자리) */
  productCostRate: number;
  /** 총수수료율 (%, 소수점 둘째 자리) */
  totalFeeRate: number;
}

export type SellerMarginInputField = keyof SellerMarginInput;

export type SellerMarginValidationField =
  | SellerMarginInputField
  | "productSalesAmount"
  | "paymentAmount"
  | "calculation";

export type SellerMarginValidationErrorCode =
  | "INVALID_NUMBER"
  | "MUST_BE_POSITIVE"
  | "MUST_BE_INTEGER"
  | "MUST_BE_SAFE_INTEGER"
  | "MUST_BE_NON_NEGATIVE"
  | "AMOUNT_EXCEEDS_LIMIT"
  | "QUANTITY_EXCEEDS_LIMIT"
  | "CALCULATION_EXCEEDS_SAFE_RANGE"
  | "RATE_OUT_OF_RANGE"
  | "DISCOUNT_EXCEEDS_PRODUCT_SALES"
  | "ZERO_DENOMINATOR";

export interface SellerMarginValidationError {
  field: SellerMarginValidationField;
  code: SellerMarginValidationErrorCode;
  message: string;
}

export type SellerMarginCalculationResponse =
  | {
      success: true;
      data: SellerMarginResult;
    }
  | {
      success: false;
      errors: SellerMarginValidationError[];
    };

const inputFields: SellerMarginInputField[] = [
  "unitPrice",
  "quantity",
  "sellerDiscount",
  "customerShippingFee",
  "unitProductCost",
  "platformFeeRate",
  "paymentFeeRate",
  "sellerShippingCost",
  "allocatedAdCost",
  "otherCost",
];

const nonNegativeAmountFields: SellerMarginInputField[] = [
  "sellerDiscount",
  "customerShippingFee",
  "unitProductCost",
  "sellerShippingCost",
  "allocatedAdCost",
  "otherCost",
];

const amountFields: SellerMarginInputField[] = [
  "unitPrice",
  ...nonNegativeAmountFields,
];

const rateFields: SellerMarginInputField[] = [
  "platformFeeRate",
  "paymentFeeRate",
];

const maximumSafeMoney = BigInt(Number.MAX_SAFE_INTEGER);
const minimumSafeMoney = BigInt(Number.MIN_SAFE_INTEGER);
const derivedMoneyRangeErrorMessage =
  "입력값 조합이 너무 커 정확한 원 단위 계산이 어렵습니다. 판매단가, 판매수량 또는 비용을 줄여 주세요.";

interface SellerMarginDerivedAmounts {
  productSalesAmount: number;
  paymentAmount: number;
  platformFee: number;
  paymentFee: number;
  totalFees: number;
  estimatedSettlement: number;
  totalProductCost: number;
  totalCosts: number;
  estimatedNetProfit: number;
}

/**
 * 법정·플랫폼 정책값이 아닌 서비스 입력 제한입니다.
 * 다른 금액형 공개 계산기와 같은 100억원 한도를 사용해 일반적인 주문 입력은
 * 충분히 허용하면서, 브라우저 숫자 정밀도 밖의 금액은 계산 전에 차단합니다.
 */
export const SELLER_MARGIN_SERVICE_LIMITS = {
  maximumAmount: 10_000_000_000,
  maximumQuantity: 1_000_000,
} as const;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function isSafeIntegerProduct(left: number, right: number): boolean {
  return safeMultiply(left, right) !== null;
}

function isSafeMoney(value: number): boolean {
  return Number.isFinite(value) && Number.isSafeInteger(value);
}

function toSafeMoney(value: bigint): number | null {
  if (value < minimumSafeMoney || value > maximumSafeMoney) {
    return null;
  }

  return Number(value);
}

function safeAdd(left: number, right: number): number | null {
  if (!isSafeMoney(left) || !isSafeMoney(right)) {
    return null;
  }

  return toSafeMoney(BigInt(left) + BigInt(right));
}

function safeSubtract(left: number, right: number): number | null {
  if (!isSafeMoney(left) || !isSafeMoney(right)) {
    return null;
  }

  return toSafeMoney(BigInt(left) - BigInt(right));
}

function safeMultiply(left: number, right: number): number | null {
  if (!isSafeMoney(left) || !isSafeMoney(right)) {
    return null;
  }

  return toSafeMoney(BigInt(left) * BigInt(right));
}

function calculateRoundedFee(baseAmount: number, rate: number): number | null {
  if (!isSafeMoney(baseAmount) || !Number.isFinite(rate)) {
    return null;
  }

  const rateMagnitude = Math.abs(rate);
  const canMultiplyBeforeDivide =
    rateMagnitude === 0 ||
    Math.abs(baseAmount) <= Number.MAX_SAFE_INTEGER / rateMagnitude;
  const unroundedFee = canMultiplyBeforeDivide
    ? (baseAmount * rate) / 100
    : baseAmount * (rate / 100);

  if (!Number.isFinite(unroundedFee)) {
    return null;
  }

  const roundedFee = roundToWon(unroundedFee);
  return isSafeMoney(roundedFee) ? roundedFee : null;
}

function calculateSafeDerivedAmounts(
  input: SellerMarginInput,
): SellerMarginDerivedAmounts | null {
  const productSalesAmount = safeMultiply(input.unitPrice, input.quantity);

  if (productSalesAmount === null) {
    return null;
  }

  const discountedAmount = safeSubtract(
    productSalesAmount,
    input.sellerDiscount,
  );
  const paymentAmount =
    discountedAmount === null
      ? null
      : safeAdd(discountedAmount, input.customerShippingFee);

  if (paymentAmount === null) {
    return null;
  }

  const platformFee = calculateRoundedFee(
    productSalesAmount,
    input.platformFeeRate,
  );
  const paymentFee = calculateRoundedFee(paymentAmount, input.paymentFeeRate);

  if (platformFee === null || paymentFee === null) {
    return null;
  }

  const totalFees = safeAdd(platformFee, paymentFee);
  const estimatedSettlement =
    totalFees === null ? null : safeSubtract(paymentAmount, totalFees);
  const totalProductCost = safeMultiply(
    input.unitProductCost,
    input.quantity,
  );

  if (
    totalFees === null ||
    estimatedSettlement === null ||
    totalProductCost === null
  ) {
    return null;
  }

  const costAfterShipping = safeAdd(
    totalProductCost,
    input.sellerShippingCost,
  );
  const costAfterAdvertising =
    costAfterShipping === null
      ? null
      : safeAdd(costAfterShipping, input.allocatedAdCost);
  const totalCosts =
    costAfterAdvertising === null
      ? null
      : safeAdd(costAfterAdvertising, input.otherCost);
  const estimatedNetProfit =
    totalCosts === null ? null : safeSubtract(estimatedSettlement, totalCosts);

  if (totalCosts === null || estimatedNetProfit === null) {
    return null;
  }

  return {
    productSalesAmount,
    paymentAmount,
    platformFee,
    paymentFee,
    totalFees,
    estimatedSettlement,
    totalProductCost,
    totalCosts,
    estimatedNetProfit,
  };
}

function hasFiniteInputFields(
  input: Record<string, unknown>,
): input is Record<string, unknown> & SellerMarginInput {
  return inputFields.every((field) => isFiniteNumber(input[field]));
}

/**
 * 0.5 경계는 0에서 먼 방향으로 반올림합니다.
 * 지수 이동을 문자열로 수행해 1.005 같은 값의 이진 부동소수점 경계 오차가
 * 소수점 둘째 자리 반올림 결과에 노출되지 않게 합니다.
 */
export function roundToDecimalPlaces(value: number, decimalPlaces: number): number {
  if (!Number.isFinite(value) || !Number.isInteger(decimalPlaces)) {
    throw new TypeError("A finite number and an integer decimal place are required.");
  }

  const sign = value < 0 ? -1 : 1;
  const absoluteValue = Math.abs(value);
  const [coefficient, exponent = "0"] = absoluteValue.toString().split("e");
  const shifted = Number(`${coefficient}e${Number(exponent) + decimalPlaces}`);
  const rounded = Math.round(shifted);
  const [roundedCoefficient, roundedExponent = "0"] = rounded
    .toString()
    .split("e");
  const restored = Number(
    `${roundedCoefficient}e${Number(roundedExponent) - decimalPlaces}`,
  );

  return sign * restored;
}

/** 금액을 원 단위 정수로 반올림합니다. */
export function roundToWon(value: number): number {
  return roundToDecimalPlaces(value, 0);
}

function addError(
  errors: SellerMarginValidationError[],
  field: SellerMarginValidationField,
  code: SellerMarginValidationErrorCode,
  message: string,
) {
  errors.push({ field, code, message });
}

export function validateSellerMarginInput(
  input: unknown,
): SellerMarginValidationError[] {
  const errors: SellerMarginValidationError[] = [];

  if (!isRecord(input)) {
    return inputFields.map((field) => ({
      field,
      code: "INVALID_NUMBER",
      message: `${field} 값은 유한한 숫자여야 합니다.`,
    }));
  }

  for (const field of inputFields) {
    if (!isFiniteNumber(input[field])) {
      addError(
        errors,
        field,
        "INVALID_NUMBER",
        `${field} 값은 유한한 숫자여야 합니다.`,
      );
    }
  }

  for (const field of amountFields) {
    const value = input[field];

    if (!isFiniteNumber(value)) {
      continue;
    }

    if (!Number.isInteger(value)) {
      addError(
        errors,
        field,
        "MUST_BE_INTEGER",
        `${field} 값은 원 단위 정수여야 합니다.`,
      );
    } else if (!Number.isSafeInteger(value)) {
      addError(
        errors,
        field,
        "MUST_BE_SAFE_INTEGER",
        `${field} 값이 안전한 정수 범위를 벗어났습니다.`,
      );
    } else if (value > SELLER_MARGIN_SERVICE_LIMITS.maximumAmount) {
      addError(
        errors,
        field,
        "AMOUNT_EXCEEDS_LIMIT",
        `${field} 값은 ${SELLER_MARGIN_SERVICE_LIMITS.maximumAmount.toLocaleString("ko-KR")}원 이하여야 합니다.`,
      );
    }
  }

  if (isFiniteNumber(input.unitPrice) && input.unitPrice <= 0) {
    addError(
      errors,
      "unitPrice",
      "MUST_BE_POSITIVE",
      "상품 판매단가는 0보다 커야 합니다.",
    );
  }

  if (isFiniteNumber(input.quantity)) {
    if (input.quantity < 1) {
      addError(
        errors,
        "quantity",
        "MUST_BE_POSITIVE",
        "판매수량은 1 이상이어야 합니다.",
      );
    }

    if (!Number.isInteger(input.quantity)) {
      addError(
        errors,
        "quantity",
        "MUST_BE_INTEGER",
        "판매수량은 정수여야 합니다.",
      );
    } else if (!Number.isSafeInteger(input.quantity)) {
      addError(
        errors,
        "quantity",
        "MUST_BE_SAFE_INTEGER",
        "판매수량이 안전한 정수 범위를 벗어났습니다.",
      );
    } else if (input.quantity > SELLER_MARGIN_SERVICE_LIMITS.maximumQuantity) {
      addError(
        errors,
        "quantity",
        "QUANTITY_EXCEEDS_LIMIT",
        `판매수량은 ${SELLER_MARGIN_SERVICE_LIMITS.maximumQuantity.toLocaleString("ko-KR")}개 이하여야 합니다.`,
      );
    }
  }

  for (const field of nonNegativeAmountFields) {
    const value = input[field];

    if (isFiniteNumber(value) && value < 0) {
      addError(
        errors,
        field,
        "MUST_BE_NON_NEGATIVE",
        `${field} 값은 0 이상이어야 합니다.`,
      );
    }
  }

  for (const field of rateFields) {
    const value = input[field];

    if (isFiniteNumber(value) && (value < 0 || value > 100)) {
      addError(
        errors,
        field,
        "RATE_OUT_OF_RANGE",
        `${field} 값은 0% 이상 100% 이하여야 합니다.`,
      );
    }
  }

  const unitPrice = input.unitPrice;
  const quantity = input.quantity;
  const canCalculateProductSales =
    isFiniteNumber(unitPrice) &&
    unitPrice > 0 &&
    isFiniteNumber(quantity) &&
    quantity >= 1 &&
    Number.isInteger(quantity) &&
    Number.isSafeInteger(unitPrice) &&
    Number.isSafeInteger(quantity) &&
    unitPrice <= SELLER_MARGIN_SERVICE_LIMITS.maximumAmount &&
    quantity <= SELLER_MARGIN_SERVICE_LIMITS.maximumQuantity;

  if (canCalculateProductSales) {
    const productSalesAmount = safeMultiply(unitPrice, quantity);

    if (productSalesAmount === null) {
      addError(
        errors,
        "unitPrice",
        "CALCULATION_EXCEEDS_SAFE_RANGE",
        "상품 판매단가와 판매수량의 곱이 안전한 정수 범위를 넘습니다.",
      );
      return errors;
    }

    if (
      isFiniteNumber(input.unitProductCost) &&
      Number.isSafeInteger(input.unitProductCost) &&
      input.unitProductCost <= SELLER_MARGIN_SERVICE_LIMITS.maximumAmount &&
      !isSafeIntegerProduct(input.unitProductCost, quantity)
    ) {
      addError(
        errors,
        "unitProductCost",
        "CALCULATION_EXCEEDS_SAFE_RANGE",
        "상품 1개당 원가와 판매수량의 곱이 안전한 정수 범위를 넘습니다.",
      );
      return errors;
    }

    if (
      isFiniteNumber(input.sellerDiscount) &&
      input.sellerDiscount > productSalesAmount
    ) {
      addError(
        errors,
        "sellerDiscount",
        "DISCOUNT_EXCEEDS_PRODUCT_SALES",
        "판매자 부담 할인금액은 상품 판매금액보다 클 수 없습니다.",
      );
    }

    if (productSalesAmount === 0) {
      addError(
        errors,
        "productSalesAmount",
        "ZERO_DENOMINATOR",
        "상품 판매금액이 0이면 원가율을 계산할 수 없습니다.",
      );
    }

    if (
      isFiniteNumber(input.sellerDiscount) &&
      isFiniteNumber(input.customerShippingFee) &&
      input.sellerDiscount <= productSalesAmount
    ) {
      const discountedAmount = safeSubtract(
        productSalesAmount,
        input.sellerDiscount,
      );
      const paymentAmount =
        discountedAmount === null
          ? null
          : safeAdd(discountedAmount, input.customerShippingFee);

      if (paymentAmount === null) {
        addError(
          errors,
          "calculation",
          "CALCULATION_EXCEEDS_SAFE_RANGE",
          derivedMoneyRangeErrorMessage,
        );
      } else if (paymentAmount === 0) {
        addError(
          errors,
          "paymentAmount",
          "ZERO_DENOMINATOR",
          "결제금액이 0이면 순이익률과 총수수료율을 계산할 수 없습니다.",
        );
      }
    }
  }

  if (errors.length === 0 && hasFiniteInputFields(input)) {
    const derivedAmounts = calculateSafeDerivedAmounts(input);

    if (derivedAmounts === null) {
      addError(
        errors,
        "calculation",
        "CALCULATION_EXCEEDS_SAFE_RANGE",
        derivedMoneyRangeErrorMessage,
      );
    }
  }

  return errors;
}

export function calculateSellerMargin(
  input: unknown,
): SellerMarginCalculationResponse {
  const errors = validateSellerMarginInput(input);

  if (
    errors.length > 0 ||
    !isRecord(input) ||
    !hasFiniteInputFields(input)
  ) {
    return { success: false, errors };
  }

  const derivedAmounts = calculateSafeDerivedAmounts(input);

  if (derivedAmounts === null) {
    return {
      success: false,
      errors: [
        {
          field: "calculation",
          code: "CALCULATION_EXCEEDS_SAFE_RANGE",
          message: derivedMoneyRangeErrorMessage,
        },
      ],
    };
  }

  return {
    success: true,
    data: {
      productSalesAmount: derivedAmounts.productSalesAmount,
      paymentAmount: derivedAmounts.paymentAmount,
      platformFee: derivedAmounts.platformFee,
      paymentFee: derivedAmounts.paymentFee,
      totalFees: derivedAmounts.totalFees,
      estimatedSettlement: derivedAmounts.estimatedSettlement,
      totalCosts: derivedAmounts.totalCosts,
      estimatedNetProfit: derivedAmounts.estimatedNetProfit,
      netProfitMarginRate: roundToDecimalPlaces(
        (derivedAmounts.estimatedNetProfit / derivedAmounts.paymentAmount) *
          100,
        2,
      ),
      productCostRate: roundToDecimalPlaces(
        (derivedAmounts.totalProductCost / derivedAmounts.productSalesAmount) *
          100,
        2,
      ),
      totalFeeRate: roundToDecimalPlaces(
        (derivedAmounts.totalFees / derivedAmounts.paymentAmount) * 100,
        2,
      ),
    },
  };
}
