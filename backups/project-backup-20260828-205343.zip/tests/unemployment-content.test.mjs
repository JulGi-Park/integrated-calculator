import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { metadata } from "../app/calculators/unemployment/page.tsx";
import { serializeJsonLd } from "../components/common/JsonLdScripts.tsx";
import { UnemploymentContent } from "../components/calculators/UnemploymentContent.tsx";
import {
  unemploymentBreadcrumbJsonLd,
  unemploymentCriteriaRows,
  unemploymentDirectAnswerItems,
  unemploymentExampleInput,
  unemploymentExampleResultItems,
  unemploymentExcludedItems,
  unemploymentFaqJsonLd,
  unemploymentFaqs,
  unemploymentInterpretationCards,
  unemploymentQuickCheckRows,
  unemploymentRelatedCalculators,
  unemploymentSources,
  unemploymentMinimumWage2026,
  unemploymentMinimumWageBenefitRate,
  unemploymentScheduledHoursLowerLimits,
  unemploymentStandardDailyHours,
  unemploymentUpperBasisDailyWage,
  unemploymentWebApplicationJsonLd,
} from "../components/calculators/unemploymentContentData.ts";
import { UNEMPLOYMENT_POLICY_2026 } from "../lib/calculators/unemployment/policy.ts";

const pageSource = await readFile(
  "app/calculators/unemployment/page.tsx",
  "utf8",
);
const contentSource = await readFile(
  "components/calculators/UnemploymentContent.tsx",
  "utf8",
);
const dataSource = await readFile(
  "components/calculators/unemploymentContentData.ts",
  "utf8",
);
const renderedContent = renderToStaticMarkup(
  React.createElement(UnemploymentContent),
);

test("실업급여 계산기 SEO 메타데이터를 검색 유입 페이지에 맞게 보강한다", () => {
  const expectedTitle =
    "실업급여 계산기 2026 | 구직급여 상한액·하한액·수급기간 예상";
  const expectedDescription =
    "실업급여 계산기로 퇴직 전 임금 기준 1일 구직급여액, 상한액·하한액 적용 여부, 고용보험 가입기간별 수급기간과 예상 총액을 확인하세요. 실제 지급 여부는 퇴직 사유, 이직확인서, 실업인정 절차에 따라 달라질 수 있습니다.";
  const expectedOgTitle =
    "실업급여 계산기 - 구직급여 예상 금액·수급기간 확인";
  const expectedOgDescription =
    "퇴사 전 임금과 고용보험 가입 기간을 기준으로 실업급여 예상 금액과 수급기간을 확인할 수 있습니다.";
  const expectedOgImage = "https://gyesanbox.kr/og/unemployment.png";

  assert.equal(metadata.title, expectedTitle);
  assert.equal(metadata.description, expectedDescription);
  assert.deepEqual(metadata.robots, { index: true, follow: true });
  assert.equal(metadata.openGraph.title, expectedOgTitle);
  assert.equal(metadata.openGraph.description, expectedOgDescription);
  assert.equal(metadata.openGraph.type, "website");
  assert.deepEqual(metadata.openGraph.images, [
    {
      url: expectedOgImage,
      width: 1200,
      height: 630,
      alt: expectedOgTitle,
    },
  ]);
  assert.equal(metadata.twitter.card, "summary_large_image");
  assert.equal(metadata.twitter.title, expectedOgTitle);
  assert.equal(metadata.twitter.description, expectedOgDescription);
  assert.deepEqual(metadata.twitter.images, [expectedOgImage]);
  assert.deepEqual(metadata.alternates, {
    canonical: "https://gyesanbox.kr/calculators/unemployment/",
  });
  assert.equal(metadata.openGraph.url, "https://gyesanbox.kr/calculators/unemployment/");

  const metadataText = JSON.stringify(metadata);
  assert.match(metadataText, /실업급여 계산기/);
  assert.match(metadataText, /구직급여/);
  assert.match(metadataText, /상한액/);
  assert.match(metadataText, /하한액/);
  assert.match(metadataText, /수급기간/);
  assert.doesNotMatch(
    metadataText,
    /localhost|127\.0\.0\.1|pages\.dev|example\.com|www\.gyesanbox\.kr/,
  );
});

test("페이지 상단은 H1 하나와 계산기, 본문 콘텐츠, JSON-LD 세 종류를 유지한다", () => {
  assert.equal((pageSource.match(/<CompactCalculatorHero\b/g) ?? []).length, 1);
  assert.equal((pageSource.match(/title="실업급여 계산기"/g) ?? []).length, 1);
  assert.match(pageSource, /<UnemploymentCalculator \/>/);
  assert.match(pageSource, /<UnemploymentContent \/>/);
  assert.match(pageSource, /unemploymentWebApplicationJsonLd/);
  assert.match(pageSource, /unemploymentBreadcrumbJsonLd/);
  assert.match(pageSource, /unemploymentFaqJsonLd/);
  assert.match(pageSource, /<JsonLdScripts items=\{jsonLdItems\}/);
});

test("첫 화면은 계산기 입력과 핵심 결과를 직접 연결한다", () => {
  assert.match(
    pageSource,
    /월급 또는 1일 평균임금, 고용보험 가입기간·연령·퇴직 사유를 입력해/,
  );
  assert.match(pageSource, /1일 예상 구직급여액/);
  assert.match(pageSource, /상한·하한 적용 여부/);
  assert.match(pageSource, /예상\s*소정급여일수/);
  assert.match(pageSource, /총 지급액/);
});

test("주요 본문 섹션을 모두 렌더링한다", () => {
  const headings = [
    "2026년 실업급여 핵심 기준",
    "실업급여 계산 전 먼저 확인할 항목",
    "2026년 실업급여 계산 기준",
    "1일 구직급여액 계산 방식",
    "시간별 하한액·상한액 적용 방식",
    "고용보험 가입기간과 소정급여일수",
    "자발적 퇴사와 예외 인정 가능성",
    "이직확인서와 실업인정 절차",
    "계산 예시",
    "결과 해석 방법",
    "공식 출처",
    "면책 문구",
  ];

  for (const heading of headings) {
    assert.match(renderedContent, new RegExp(heading));
  }

  assert.equal(unemploymentInterpretationCards.length, 4);
  assert.equal(unemploymentDirectAnswerItems.length, 4);
  assert.ok(unemploymentExcludedItems.length >= 6);
  assert.match(renderedContent, /신청 전 체크리스트/);
});

test("자발적 퇴사 예외 상세 영역을 정적 details로 렌더링한다", () => {
  const anchorId = "voluntary-resignation-exceptions";
  const summaryText = "자발적 퇴사 예외 조건과 준비할 증빙 자세히 보기";
  assert.match(contentSource, /<details className=\{styles\.reasonDetails\}>/);
  assert.match(
    contentSource,
    /<summary\s+id="voluntary-resignation-exceptions"\s+className=\{styles\.reasonSummary\}\s*>/,
  );
  assert.match(renderedContent, /<details class="[^"]*reasonDetails[^"]*">/);
  assert.match(
    renderedContent,
    new RegExp(
      `<summary id="${anchorId}" class="[^"]*reasonSummary[^"]*">${summaryText}<\\/summary>`,
    ),
  );
  assert.equal((contentSource.match(new RegExp(anchorId, "g")) ?? []).length, 1);
  assert.equal((renderedContent.match(new RegExp(anchorId, "g")) ?? []).length, 1);

  for (const heading of [
    "1. 자발적 퇴사의 기본 원칙",
    "2. 함께 충족해야 하는 기본 수급요건",
    "3. 임금체불 또는 근로조건 저하",
    "4. 직장 내 괴롭힘·성희롱·차별",
    "5. 사업장 이전·전근 등으로 통근이 곤란해진 경우",
    "6. 본인의 질병·부상으로 기존 업무가 어려운 경우",
    "7. 가족을 30일 이상 간호해야 하는 경우",
    "8. 임신·출산·육아로 계속 근무하기 어려운 경우",
    "9. 회사의 경영상 사유",
    "10. 그 밖의 인정 가능 사유",
    "11. 인정받기 어려운 대표 사례",
    "12. 퇴사 전에 준비할 사항",
    "13. 최종 판단 안내",
  ]) {
    assert.match(renderedContent, new RegExp(heading));
  }

  for (const phrase of [
    "피보험단위기간 180일",
    "왕복 출퇴근 시간 3시간 이상",
    "질병·부상",
    "관할 고용센터가 최종 판단",
    "실제 수급 가능 여부 또는 고용센터 심사 결과를 판정하지 않습니다",
  ]) {
    assert.match(renderedContent, new RegExp(phrase));
  }

  assert.equal(
    (renderedContent.match(/자발적 퇴사 예외 조건과 준비할 증빙 자세히 보기/g) ?? [])
      .length,
    1,
  );
});

test("표 2개 이상과 요구된 표 제목을 렌더링한다", () => {
  assert.equal((renderedContent.match(/<table/g) ?? []).length, 2);
  assert.match(renderedContent, /빠른 판단표/);
  assert.match(renderedContent, /계산 기준 요약표/);
  assert.ok(unemploymentQuickCheckRows.length >= 5);
  assert.ok(unemploymentCriteriaRows.length >= 8);
});

test("계산 예시는 현재 엔진 결과와 같은 확정값을 사용한다", () => {
  assert.deepEqual(unemploymentExampleInput, {
    wageInputType: "monthlyWage",
    wageAmount: 3_300_000,
    scheduledDailyHours: 8,
    insuredMonths: 36,
    ageGroup: "under50",
    leavingReason: "involuntary",
  });

  assert.deepEqual(unemploymentExampleResultItems, [
    { label: "추정 1일 평균임금", value: "110,000원" },
    { label: "계산 전 기준 급여액", value: "66,000원" },
    { label: "적용 하한액", value: "66,048원" },
    { label: "1일 예상 구직급여액", value: "66,048원" },
    { label: "예상 소정급여일수", value: "180일" },
    { label: "예상 총 지급액", value: "11,888,640원" },
  ]);

  assert.match(dataSource, /calculateUnemploymentBenefit\(/);
});

test("FAQ 8개를 데이터 파일에서 관리하고 FAQPage JSON-LD와 일치한다", () => {
  const expectedQuestions = [
    "실업급여 계산기는 실제 지급액과 같은가요?",
    "월급만 알아도 실업급여를 계산할 수 있나요?",
    "2026년 실업급여 하루 상한액과 하한액은 얼마인가요?",
    "급여기초 임금일액 113,500원은 실제로 받는 하루 실업급여인가요?",
    "자발적 퇴사도 실업급여를 받을 수 있나요?",
    "실업급여 지급일수는 어떻게 계산하나요?",
    "월급이 80만원이면 하한액이 바로 적용되나요?",
    "이직확인서와 실업인정은 계산 결과와 어떤 관계가 있나요?",
  ];

  assert.deepEqual(
    unemploymentFaqs.map((faq) => faq.question),
    expectedQuestions,
  );
  assert.equal(unemploymentFaqJsonLd.mainEntity.length, 8);
  assert.match(contentSource, /unemploymentFaqs\.map/);
  assert.match(renderedContent, /<details/);

  for (const [index, faq] of unemploymentFaqs.entries()) {
    assert.equal(unemploymentFaqJsonLd.mainEntity[index].name, faq.question);
    assert.equal(
      unemploymentFaqJsonLd.mainEntity[index].acceptedAnswer.text,
      faq.answer,
    );
  }
});

test("공식 출처 섹션과 외부 링크 보안 속성을 제공한다", () => {
  assert.ok(unemploymentSources.length >= 8);
  assert.match(renderedContent, /공식 출처/);
  assert.match(contentSource, /target="_blank" rel="noopener noreferrer"/);

  const organizations = unemploymentSources.map((source) => source.organization);
  assert.ok(organizations.includes("고용24"));
  assert.ok(organizations.includes("고용노동부"));
  assert.ok(organizations.includes("국가법령정보센터"));
  assert.ok(organizations.includes("최저임금위원회"));
  assert.equal(
    unemploymentSources.some((source) => source.title.includes("제45조")),
    true,
  );
  assert.equal(
    unemploymentSources.some((source) => source.title.includes("제46조")),
    true,
  );
  assert.equal(
    unemploymentSources.some((source) => source.title.includes("시행령 제68조")),
    true,
  );

  for (const source of unemploymentSources) {
    assert.equal(source.checkedAt, "2026-06-25");
    assert.ok(source.criterion.length > 0);
    assert.match(
      source.href,
      /^https:\/\/(m\.work24\.go\.kr|www\.law\.go\.kr|www\.moel\.go\.kr|1350\.moel\.go\.kr|www\.minimumwage\.go\.kr|www\.easylaw\.go\.kr)\//,
    );
  }
});

test("2026년 상한액과 하한액 산식을 공식 기준 문구로 표시한다", () => {
  assert.equal(unemploymentUpperBasisDailyWage, 113_500);
  assert.equal(unemploymentMinimumWage2026, 10_320);
  assert.equal(unemploymentStandardDailyHours, 8);
  assert.equal(unemploymentMinimumWageBenefitRate, 80);
  assert.match(renderedContent, /113,500원/);
  assert.match(renderedContent, /68,100원/);
  assert.match(renderedContent, /시행령 제68조의 113,500원은 급여기초 임금일액의 상한/);
  assert.match(renderedContent, /제68조가 아니라 2026년 최저임금/);
  assert.match(renderedContent, /113,500원 자체가 실제 하루 구직급여 상한액은 아닙니다/);
  assert.match(renderedContent, /66,048원입니다\. 실제 인정 시간은/);
  assert.match(renderedContent, /10,320원/);
  assert.match(renderedContent, /8시간/);
  assert.match(renderedContent, /80%/);
  assert.match(renderedContent, /66,048원/);
  assert.match(renderedContent, /33,024원/);
  assert.match(renderedContent, /49,536원/);
  assert.match(renderedContent, /소정근로시간/);
  assert.match(renderedContent, /2026년 공식 기준/);
  assert.deepEqual(unemploymentScheduledHoursLowerLimits, [
    { hours: "4시간 이하", amount: 33_024 },
    { hours: "5시간", amount: 41_280 },
    { hours: "6시간", amount: 49_536 },
    { hours: "7시간", amount: 57_792 },
    { hours: "8시간 이상", amount: 66_048 },
  ]);
});

test("상한·하한 법령 설명은 시행령 제68조와 제46조의 역할을 분리한다", () => {
  const text = JSON.stringify([
    unemploymentInterpretationCards,
    unemploymentDirectAnswerItems,
    unemploymentCriteriaRows,
    unemploymentFaqs,
  ]);

  assert.match(text, /시행령 제68조/);
  assert.match(text, /제46조/);
  assert.match(text, /113,500원.*60%.*68,100원/);
  assert.match(text, /하한액은 제68조가 아니라/);
  assert.match(text, /66,048원/);
  assert.doesNotMatch(text, /113,500원을 하한액/);
});

test("관련 계산기는 기존 구현 URL만 활성 링크로 제공한다", () => {
  assert.deepEqual(
    unemploymentRelatedCalculators.map((item) => item.href),
    [
      "/calculators/severance/",
      "/calculators/salary/",
      "/calculators/loan/",
      "/calculators/seller-margin/",
    ],
  );

  assert.doesNotMatch(
    dataSource,
    /\/calculators\/(?:hourly|overtime|night|tax|vat|pension|unimplemented)/,
  );
});

test("수급 판단을 단정하거나 승인 보장 표현을 사용하지 않는다", () => {
  const combined = [renderedContent, JSON.stringify(unemploymentFaqJsonLd)].join(
    "\n",
  );
  const bannedPatterns = [
    /수급\s*확정/,
    /승인\s*보장/,
    /지급\s*보장/,
    /100%\s*지급/,
    /무조건\s*받을\s*수/,
    /실제\s*지급액과\s*동일/,
    /공식\s*기준\s*미확정/,
    /공식\s*안내와\s*차이가\s*있을\s*수\s*있음/,
    /애드센스\s*승인\s*보장/,
    /고용센터\s*심사\s*없이\s*가능/,
    /자발적\s*퇴사도\s*모두\s*가능/,
  ];

  for (const pattern of bannedPatterns) {
    assert.doesNotMatch(combined, pattern);
  }
});

test("WebApplication, BreadcrumbList와 FAQPage JSON-LD가 안전하다", () => {
  const items = [
    unemploymentWebApplicationJsonLd,
    unemploymentBreadcrumbJsonLd,
    unemploymentFaqJsonLd,
  ];

  assert.deepEqual(
    items.map((item) => item["@type"]),
    ["WebApplication", "BreadcrumbList", "FAQPage"],
  );
  assert.equal(
    unemploymentWebApplicationJsonLd.applicationCategory,
    "FinanceApplication",
  );
  assert.equal(unemploymentWebApplicationJsonLd.name, "실업급여 계산기");
  assert.equal(unemploymentWebApplicationJsonLd.url, "/calculators/unemployment/");
  assert.deepEqual(
    unemploymentBreadcrumbJsonLd.itemListElement.map((item) => item.name),
    ["홈", "계산기 목록", "실업급여 계산기"],
  );
  assert.deepEqual(
    unemploymentBreadcrumbJsonLd.itemListElement.map((item) => item.item),
    [
      "https://gyesanbox.kr/",
      "https://gyesanbox.kr/calculators/",
      "https://gyesanbox.kr/calculators/unemployment/",
    ],
  );

  for (const item of items) {
    const serialized = serializeJsonLd(item);
    assert.deepEqual(JSON.parse(serialized), item);
    assert.doesNotMatch(
      serialized,
      /aggregateRating|review|offers|NaN|Infinity|undefined|localhost|127\.0\.0\.1|pages\.dev|연봉 실수령액 계산기|판매자 마진 계산기/,
    );
  }
});

test("policy 설명 필드는 공식 확인 완료 상태와 충돌하지 않는다", () => {
  assert.equal(UNEMPLOYMENT_POLICY_2026.needsOfficialVerification, false);
  assert.match(UNEMPLOYMENT_POLICY_2026.sourceNote, /공식 기준/);
  assert.match(UNEMPLOYMENT_POLICY_2026.sourceNote, /113,500원 × 60%/);
  assert.match(UNEMPLOYMENT_POLICY_2026.sourceNote, /10,320원 × 1시간 × 80%/);
  assert.doesNotMatch(UNEMPLOYMENT_POLICY_2026.sourceNote, /재검증|미확정|차이/);
  assert.equal(UNEMPLOYMENT_POLICY_2026.dailyBenefitUpperLimit, 68_100);
  assert.equal(UNEMPLOYMENT_POLICY_2026.dailyBenefitLowerLimit, 66_048);
});
