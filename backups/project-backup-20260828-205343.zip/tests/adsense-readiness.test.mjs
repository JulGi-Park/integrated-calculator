import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import { join, sep } from "node:path";
import test from "node:test";
import sitemapModule from "../app/sitemap.ts";

const sitemap = sitemapModule.default;

const sourceRoots = ["app", "components", "lib", "public"];
const sourceExtensions = new Set([".ts", ".tsx", ".txt"]);
const routeFiles = [
  ["app/page.tsx", "/"],
  ["app/calculators/page.tsx", "/calculators/"],
  ["app/calculators/seller-margin/page.tsx", "/calculators/seller-margin/"],
  ["app/calculators/vat-profit/page.tsx", "/calculators/vat-profit/"],
  ["app/calculators/salary/page.tsx", "/calculators/salary/"],
  ["app/calculators/social-insurance/page.tsx", "/calculators/social-insurance/"],
  ["app/calculators/labor-pay/page.tsx", "/calculators/labor-pay/"],
  ["app/calculators/loan/page.tsx", "/calculators/loan/"],
  ["app/calculators/severance/page.tsx", "/calculators/severance/"],
  ["app/calculators/unemployment/page.tsx", "/calculators/unemployment/"],
  ["app/calculators/parental-leave/page.tsx", "/calculators/parental-leave/"],
  ["app/calculators/rent-vs-jeonse/page.tsx", "/calculators/rent-vs-jeonse/"],
  ["app/calculators/roas/page.tsx", "/calculators/roas/"],
  ["app/calculators/savings/page.tsx", "/calculators/savings/"],
  ["app/calculators/average-price/page.tsx", "/calculators/average-price/"],
  ["app/calculators/card-installment/page.tsx", "/calculators/card-installment/"],
  ["app/calculators/brokerage-fee/page.tsx", "/calculators/brokerage-fee/"],
  ["app/calculators/car-cost/page.tsx", "/calculators/car-cost/"],
  ["app/calculators/overtime-pay/page.tsx", "/calculators/overtime-pay/"],
  ["app/calculators/youth-future-savings/page.tsx", "/calculators/youth-future-savings/"],
  ["app/calculators/dsr/page.tsx", "/calculators/dsr/"],
  ["app/calculators/work-child-incentive/page.tsx", "/calculators/work-child-incentive/"],
  ["app/calculators/training-certificate-cost/page.tsx", "/calculators/training-certificate-cost/"],
  ["app/about/page.tsx", "/about/"],
  ["app/methodology/page.tsx", "/methodology/"],
  ["app/updates/page.tsx", "/updates/"],
  ["app/contact/page.tsx", "/contact/"],
  ["app/privacy-policy/page.tsx", "/privacy-policy/"],
  ["app/terms/page.tsx", "/terms/"],
  ["app/disclaimer/page.tsx", "/disclaimer/"],
];

async function listFiles(dir) {
  const entries = await readdir(dir, { withFileTypes: true });
  const files = [];

  for (const entry of entries) {
    const path = join(dir, entry.name);

    if (entry.isDirectory()) {
      files.push(...await listFiles(path));
      continue;
    }

    if ([...sourceExtensions].some((extension) => path.endsWith(extension))) {
      files.push(path);
    }
  }

  return files;
}

function normalizePath(path) {
  return path.split(sep).join("/");
}

test("운영 소스에 placeholder나 준비 상태 문구가 남아 있지 않다", async () => {
  const files = (await Promise.all(sourceRoots.map(listFiles))).flat();
  const blockedPattern =
    /TODO|lorem ipsum|coming soon|placeholder|계산 기능 준비 중|준비 중|준비중|임시|광고를 눌러|후원/iu;

  for (const file of files) {
    const source = await readFile(file, "utf8");
    assert.doesNotMatch(
      source,
      blockedPattern,
      `${normalizePath(file)} contains a blocked readiness phrase`,
    );
  }
});

test("공개 계산기와 방법론에는 알려진 내부 개발 문구가 노출되지 않는다", async () => {
  const publicCopyFiles = [
    "components/calculators/ParentalLeaveCalculator.tsx",
    "components/calculators/LoanInterestContent.tsx",
    "components/calculators/SeveranceContent.tsx",
    "components/calculators/SeveranceCalculator.tsx",
    "components/calculators/SalaryTakeHomeContent.tsx",
    "app/methodology/page.tsx",
    "app/updates/page.tsx",
  ];
  const publicCopy = await Promise.all(
    publicCopyFiles.map((file) => readFile(file, "utf8")),
  );

  for (const phrase of [
    "비공개 검토용",
    "일반 계산 fallback 구간",
    "엔진 기반 계산 예시",
    "현재 계산 엔진",
    "현재 엔진",
    "구현된 엔진",
    "엔진 계약상",
    "정적 빌드 시",
    "계산 엔진과 숫자 처리",
    "정책 코드",
  ]) {
    assert.doesNotMatch(publicCopy.join("\n"), new RegExp(phrase));
  }
});

test("sitemap URL은 실제 App Router 페이지와 일치한다", () => {
  const routeSet = new Set(routeFiles.map(([, route]) => route));
  const sitemapRoutes = sitemap().map((entry) => {
    const url = new URL(entry.url);
    return url.pathname;
  });

  assert.deepEqual(sitemapRoutes, [...routeSet]);
});

test("정적 내부 링크는 실제 라우트만 가리킨다", async () => {
  const routeSet = new Set(routeFiles.map(([, route]) => route));
  const files = (await Promise.all(["app", "components"].map(listFiles))).flat();
  const hrefPattern = /href=(?:\{)?["'](\/[^"'#?]*)["'](?:\})?/g;

  for (const file of files) {
    const source = await readFile(file, "utf8");
    const matches = source.matchAll(hrefPattern);

    for (const match of matches) {
      const href = match[1];
      assert.equal(
        routeSet.has(href),
        true,
        `${normalizePath(file)} links to missing route ${href}`,
      );
    }
  }
});

test("AdSense 전역 스크립트는 루트 레이아웃에서 한 번만 삽입한다", async () => {
  const files = (await Promise.all(["app", "components"].map(listFiles))).flat();
  const usages = [];

  for (const file of files) {
    const source = await readFile(file, "utf8");

    if (source.includes("<AdSenseScript")) {
      usages.push(normalizePath(file));
    }
  }

  assert.deepEqual(usages, ["app/layout.tsx"]);
});

test("404는 noindex이며 광고 없는 복구 경로를 제공한다", async () => {
  const source = await readFile("app/not-found.tsx", "utf8");

  assert.match(source, /index:\s*false/);
  assert.match(source, /follow:\s*true/);
  assert.match(source, /페이지를 찾을 수 없습니다/);
  assert.match(source, /href="\/"/);
  assert.match(source, /href="\/calculators\/"/);
  assert.doesNotMatch(source, /AdSense|adsbygoogle|data-ad-slot/);
});

test("ads.txt는 공개 publisher ID를 유지하고 AdSense client는 환경변수만 사용한다", async () => {
  const [adsTxt, adsenseSource, componentSource] = await Promise.all([
    readFile("public/ads.txt", "utf8"),
    readFile("lib/adsense.ts", "utf8"),
    readFile("components/ads/AdSenseScript.tsx", "utf8"),
  ]);

  assert.match(adsTxt.trim(), /^google\.com, pub-\d{16}, DIRECT, f08c47fec0942fa0$/);
  assert.match(adsenseSource, /process\.env\.NEXT_PUBLIC_GOOGLE_ADSENSE_CLIENT/);
  assert.match(componentSource, /getConfiguredAdSenseClient/);
  assert.doesNotMatch(adsenseSource, /ca-pub-\d{16}/);
  assert.doesNotMatch(componentSource, /ca-pub-\d{16}/);
  assert.doesNotMatch(adsenseSource, /G-YMJFLPRFMV/);
  assert.doesNotMatch(adsTxt, /pub-0{16}|pub-1234567890123456/);
});
