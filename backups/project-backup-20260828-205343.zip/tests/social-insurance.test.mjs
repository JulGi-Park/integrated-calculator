import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { metadata } from "../app/calculators/social-insurance/page.tsx";
import {
  calculateSocialInsurance,
  validateSocialInsuranceInput,
} from "../lib/calculators/social-insurance/calculate.ts";
import { calculateSalaryTakeHome } from "../lib/calculators/salary-take-home/salary-take-home.ts";
import {
  SOCIAL_INSURANCE_POLICY_2026,
} from "../lib/calculators/social-insurance/constants.ts";
import {
  socialInsuranceFaqJsonLd,
  socialInsuranceFaqs,
  socialInsuranceExamples,
  socialInsuranceCriteria,
  socialInsuranceContentMeta,
  socialInsuranceSources,
  socialInsuranceWebApplicationJsonLd,
} from "../components/calculators/socialInsuranceContentData.ts";
import { buildSocialInsuranceResultText } from "../components/calculators/socialInsuranceClientUtils.ts";

const baseInput = {
  monthlySalary: 3_000_000,
  nonTaxableAmount: 200_000,
};

function assertSuccess(response) {
  assert.equal(response.success, true);
  return response.data;
}

function assertHasError(response, field, code) {
  assert.equal(response.success, false);
  assert.ok(
    response.errors.some(
      (error) => error.field === field && error.code === code,
    ),
    `${field} 필드에 ${code} 오류가 있어야 합니다.`,
  );
}

test("2026년 7월 10일 기준 공식 상수와 계산식이 기록되어 있다", () => {
  assert.equal(SOCIAL_INSURANCE_POLICY_2026.verifiedAt, "2026-07-10");
  assert.equal(SOCIAL_INSURANCE_POLICY_2026.nationalPension.totalRate, 0.095);
  assert.equal(SOCIAL_INSURANCE_POLICY_2026.nationalPension.employeeRate, 0.0475);
  assert.equal(
    SOCIAL_INSURANCE_POLICY_2026.nationalPension.standardMonthlyIncomeMinimum,
    410_000,
  );
  assert.equal(
    SOCIAL_INSURANCE_POLICY_2026.nationalPension.standardMonthlyIncomeMaximum,
    6_590_000,
  );
  assert.equal(SOCIAL_INSURANCE_POLICY_2026.healthInsurance.employeeRate, 0.03595);
  assert.equal(
    SOCIAL_INSURANCE_POLICY_2026.healthInsurance.totalMonthlyPremiumMinimum,
    20_160,
  );
  assert.equal(
    SOCIAL_INSURANCE_POLICY_2026.healthInsurance.totalMonthlyPremiumMaximum,
    9_183_480,
  );
  assert.equal(
    SOCIAL_INSURANCE_POLICY_2026.healthInsurance.employeeShareRate,
    0.5,
  );
  assert.equal(
    SOCIAL_INSURANCE_POLICY_2026.healthInsurance.employeeMonthlyPremiumMinimum,
    SOCIAL_INSURANCE_POLICY_2026.healthInsurance.totalMonthlyPremiumMinimum /
      2,
  );
  assert.equal(
    SOCIAL_INSURANCE_POLICY_2026.healthInsurance.employeeMonthlyPremiumMaximum,
    SOCIAL_INSURANCE_POLICY_2026.healthInsurance.totalMonthlyPremiumMaximum /
      2,
  );
  assert.equal(
    SOCIAL_INSURANCE_POLICY_2026.longTermCareInsurance.healthInsuranceRate,
    0.1314,
  );
  assert.equal(
    SOCIAL_INSURANCE_POLICY_2026.employmentInsurance
      .unemploymentBenefitEmployeeRate,
    0.009,
  );
});

test("보험료율 기준 설명은 계산 상수의 부동소수점 오차 없이 표시한다", () => {
  const criteria = socialInsuranceCriteria.map(({ description }) => description).join(" ");

  assert.doesNotMatch(criteria, /13\.139999999999999%/);
  assert.doesNotMatch(criteria, /0\.8999999999999999%/);
  assert.match(criteria, /장기요양보험료.*13\.14%/);
  assert.match(criteria, /실업급여 계정 근로자 부담률 0\.9%/);
  assert.match(criteria, /근로자 부담률 4\.75%/);
  assert.match(criteria, /총 보험료율 7\.19% 중 근로자 부담분 3\.595%/);
  assert.match(criteria, /20,160원~9,183,480원/);
  assert.match(criteria, /10,080원~4,591,740원/);
  assert.match(criteria, /상·하한이 보정된 근로자 건강보험료/);
});

test("월 급여 300만원·비과세 20만원의 4대보험 공제액을 계산한다", () => {
  const data = assertSuccess(calculateSocialInsurance(baseInput));

  assert.deepEqual(data, {
    monthlySalary: 3_000_000,
    nonTaxableAmount: 200_000,
    taxableMonthlyPay: 2_800_000,
    pensionBase: 2_800_000,
    pensionBaseStatus: "within",
    employeePension: 133_000,
    employeeHealthInsurance: 100_660,
    employeeLongTermCare: 13_227,
    employeeEmploymentInsurance: 25_200,
    totalEmployeeContribution: 272_087,
    afterContributionAmount: 2_727_913,
    policyYear: 2026,
    policyVerifiedAt: "2026-07-10",
  });
});

test("월 급여 250만원·비과세 0원의 예시 결과를 계산한다", () => {
  const data = assertSuccess(
    calculateSocialInsurance({
      monthlySalary: 2_500_000,
      nonTaxableAmount: 0,
    }),
  );

  assert.equal(data.employeePension, 118_750);
  assert.equal(data.employeeHealthInsurance, 89_875);
  assert.equal(data.employeeLongTermCare, 11_810);
  assert.equal(data.employeeEmploymentInsurance, 22_500);
  assert.equal(data.totalEmployeeContribution, 242_935);
  assert.equal(data.afterContributionAmount, 2_257_065);
});

test("건강보험 근로자 부담 하한과 장기요양보험 연쇄를 적용한다", () => {
  const data = assertSuccess(
    calculateSocialInsurance({
      monthlySalary: 100_000,
      nonTaxableAmount: 0,
    }),
  );

  assert.equal(data.employeePension, 19_470);
  assert.equal(data.employeeHealthInsurance, 10_080);
  assert.equal(data.employeeLongTermCare, 1_325);
  assert.equal(data.employeeEmploymentInsurance, 900);
  assert.equal(data.totalEmployeeContribution, 31_775);
  assert.equal(data.afterContributionAmount, 68_225);
});

test("건강보험 근로자 부담 상한과 장기요양보험 연쇄를 적용한다", () => {
  const data = assertSuccess(
    calculateSocialInsurance({
      monthlySalary: 1_000_000_000,
      nonTaxableAmount: 0,
    }),
  );

  assert.equal(data.employeePension, 313_020);
  assert.equal(data.employeeHealthInsurance, 4_591_740);
  assert.equal(data.employeeLongTermCare, 603_376);
  assert.equal(data.employeeEmploymentInsurance, 9_000_000);
  assert.equal(data.totalEmployeeContribution, 14_508_136);
  assert.equal(data.afterContributionAmount, 985_491_864);
});

test("건강보험 하한·상한 경계와 보정된 건강보험료 기준 장기요양보험을 검증한다", () => {
  const healthPolicy = SOCIAL_INSURANCE_POLICY_2026.healthInsurance;
  const firstMinimumRoundedSalary = Math.ceil(
    (healthPolicy.employeeMonthlyPremiumMinimum - 0.5) /
      healthPolicy.employeeRate,
  );
  const firstAboveMaximumSalary = Math.ceil(
    (healthPolicy.employeeMonthlyPremiumMaximum + 0.5) /
      healthPolicy.employeeRate,
  );

  const lowerCases = [
    [firstMinimumRoundedSalary - 1, 10_080, 1_325],
    [firstMinimumRoundedSalary, 10_080, 1_325],
    [firstMinimumRoundedSalary + 1, 10_080, 1_325],
  ];
  const upperCases = [
    [firstAboveMaximumSalary - 1, 4_591_740, 603_376],
    [firstAboveMaximumSalary, 4_591_740, 603_376],
    [firstAboveMaximumSalary + 1, 4_591_740, 603_376],
  ];

  for (const [monthlySalary, healthInsurance, longTermCare] of [
    ...lowerCases,
    ...upperCases,
  ]) {
    const data = assertSuccess(
      calculateSocialInsurance({ monthlySalary, nonTaxableAmount: 0 }),
    );
    assert.equal(data.employeeHealthInsurance, healthInsurance);
    assert.equal(data.employeeLongTermCare, longTermCare);
    assert.equal(
      data.employeeLongTermCare,
      Math.round(
        (data.employeeHealthInsurance *
          SOCIAL_INSURANCE_POLICY_2026.longTermCareInsurance.incomeRate) /
          SOCIAL_INSURANCE_POLICY_2026.healthInsurance.totalRate,
      ),
    );
  }
});

test("비과세 금액 변경으로 건강보험 상·하한 구간을 오가는 결과를 계산한다", () => {
  const lowerBeforeNonTaxable = assertSuccess(
    calculateSocialInsurance({ monthlySalary: 300_000, nonTaxableAmount: 0 }),
  );
  const lowerAfterNonTaxable = assertSuccess(
    calculateSocialInsurance({ monthlySalary: 300_000, nonTaxableAmount: 20_000 }),
  );
  const upperBeforeNonTaxable = assertSuccess(
    calculateSocialInsurance({
      monthlySalary: 127_725_745,
      nonTaxableAmount: 0,
    }),
  );
  const upperAfterNonTaxable = assertSuccess(
    calculateSocialInsurance({
      monthlySalary: 127_725_745,
      nonTaxableAmount: 29,
    }),
  );

  assert.equal(lowerBeforeNonTaxable.employeeHealthInsurance, 10_785);
  assert.equal(lowerAfterNonTaxable.taxableMonthlyPay, 280_000);
  assert.equal(lowerAfterNonTaxable.employeeHealthInsurance, 10_080);
  assert.equal(upperBeforeNonTaxable.employeeHealthInsurance, 4_591_740);
  assert.equal(upperAfterNonTaxable.taxableMonthlyPay, 127_725_716);
  assert.equal(upperAfterNonTaxable.employeeHealthInsurance, 4_591_739);
});

test("정상 계산 결과는 건강보험 범위와 총공제액 불변식을 만족한다", () => {
  const inputs = [
    { monthlySalary: 100_000, nonTaxableAmount: 0 },
    baseInput,
    { monthlySalary: 1_000_000_000, nonTaxableAmount: 0 },
  ];
  const healthPolicy = SOCIAL_INSURANCE_POLICY_2026.healthInsurance;

  for (const input of inputs) {
    const data = assertSuccess(calculateSocialInsurance(input));
    assert.ok(
      data.employeeHealthInsurance >= healthPolicy.employeeMonthlyPremiumMinimum,
    );
    assert.ok(
      data.employeeHealthInsurance <= healthPolicy.employeeMonthlyPremiumMaximum,
    );
    assert.equal(
      data.employeeLongTermCare,
      Math.round(
        (data.employeeHealthInsurance *
          SOCIAL_INSURANCE_POLICY_2026.longTermCareInsurance.incomeRate) /
          SOCIAL_INSURANCE_POLICY_2026.healthInsurance.totalRate,
      ),
    );
    assert.equal(
      data.totalEmployeeContribution,
      data.employeePension +
        data.employeeHealthInsurance +
        data.employeeLongTermCare +
        data.employeeEmploymentInsurance,
    );
    assert.equal(
      data.afterContributionAmount,
      data.monthlySalary - data.totalEmployeeContribution,
    );
    assert.ok(Object.values(data).every((value) => value !== undefined));
    assert.ok(
      Object.values(data).every(
        (value) => typeof value !== "number" || Number.isFinite(value),
      ),
    );
  }
});

test("국민연금 하한과 상한을 적용한다", () => {
  const minimum = assertSuccess(
    calculateSocialInsurance({
      monthlySalary: 300_000,
      nonTaxableAmount: 0,
    }),
  );
  const maximum = assertSuccess(
    calculateSocialInsurance({
      monthlySalary: 8_000_000,
      nonTaxableAmount: 0,
    }),
  );

  assert.equal(minimum.pensionBase, 410_000);
  assert.equal(minimum.pensionBaseStatus, "minimum");
  assert.equal(minimum.employeePension, 19_470);
  assert.equal(maximum.pensionBase, 6_590_000);
  assert.equal(maximum.pensionBaseStatus, "maximum");
  assert.equal(maximum.employeePension, 313_020);
});

test("국민연금 기준소득월액은 1,000원 미만, 근로자 부담액은 10원 미만을 절사한다", () => {
  const cases = [
    [409_999, 410_000, 19_470],
    [410_000, 410_000, 19_470],
    [410_999, 410_000, 19_470],
    [411_000, 411_000, 19_520],
    [6_000_000, 6_000_000, 285_000],
    [6_000_999, 6_000_000, 285_000],
    [6_370_000, 6_370_000, 302_570],
    [6_370_001, 6_370_000, 302_570],
    [6_370_999, 6_370_000, 302_570],
    [6_371_000, 6_371_000, 302_620],
    [6_500_000, 6_500_000, 308_750],
    [6_590_000, 6_590_000, 313_020],
    [6_590_001, 6_590_000, 313_020],
    [7_000_000, 6_590_000, 313_020],
  ];

  for (const [monthlySalary, pensionBase, employeePension] of cases) {
    const data = assertSuccess(
      calculateSocialInsurance({ monthlySalary, nonTaxableAmount: 0 }),
    );
    assert.equal(data.pensionBase, pensionBase, `${monthlySalary}원 기준소득월액`);
    assert.equal(data.employeePension, employeePension, `${monthlySalary}원 근로자 부담액`);
  }
});

test("국민연금 절사 변경은 다른 근로자 부담 보험료를 바꾸지 않고 총액·복사 출력에 반영한다", () => {
  const input = { monthlySalary: 6_590_000, nonTaxableAmount: 0 };
  const data = assertSuccess(calculateSocialInsurance(input));

  assert.equal(data.employeePension, 313_020);
  assert.equal(data.employeeHealthInsurance, 236_911);
  assert.equal(data.employeeLongTermCare, 31_131);
  assert.equal(data.employeeEmploymentInsurance, 59_310);
  assert.equal(data.totalEmployeeContribution, 640_372);
  assert.equal(data.afterContributionAmount, 5_949_628);
  assert.match(buildSocialInsuranceResultText(input, data), /국민연금: 313,020원/);
  assert.match(buildSocialInsuranceResultText(input, data), /총 공제액: 640,372원/);
});

test("복사·공유 공용 결과 문자열은 참고용 예상값 안내를 한 번 포함한다", async () => {
  const data = assertSuccess(calculateSocialInsurance(baseInput));
  const text = buildSocialInsuranceResultText(baseInput, data);
  const notice =
    "※ 이 결과는 참고용 예상값이며, 실제 공단 고지액 및 급여 공제액과 다를 수 있습니다.";

  assert.match(text, /월 급여: 3,000,000원/);
  assert.match(text, /비과세 금액: 200,000원/);
  assert.match(text, /과세기준급여: 2,800,000원/);
  assert.match(text, /국민연금: 133,000원/);
  assert.match(text, /건강보험: 100,660원/);
  assert.match(text, /장기요양보험: 13,227원/);
  assert.match(text, /고용보험: 25,200원/);
  assert.match(text, /총 공제액: 272,087원/);
  assert.match(text, /공제 후 참고 금액: 2,727,913원/);
  assert.match(text, /산재보험과 소득세·지방소득세는 포함하지 않습니다\./);
  assert.equal(text.split(notice).length - 1, 1);
  assert.equal(text.endsWith(notice), true);

  const source = await readFile(
    "components/calculators/SocialInsuranceCalculator.tsx",
    "utf8",
  );
  assert.match(source, /return buildSocialInsuranceResultText\(calculatedInput, result\)/);
  assert.match(
    source,
    /navigator\.share\(\{\s*title: "2026 4대보험 계산 결과",\s*text,\s*\}\)/s,
  );
});

test("국민연금 절사 기준 설명과 계산기 결과 영역은 같은 근로자 부담 결과를 사용한다", async () => {
  const source = await readFile(
    "components/calculators/SocialInsuranceCalculator.tsx",
    "utf8",
  );
  const pensionCriterion = socialInsuranceCriteria.find(
    ({ title }) => title === "국민연금",
  );

  assert.match(pensionCriterion.description, /1,000원 미만을 버린 뒤/);
  assert.match(pensionCriterion.description, /10원 미만을 버립니다/);
  assert.match(source, /<dt>국민연금<\/dt>\s*<dd>\{formatWon\(result\.employeePension\)\}<\/dd>/);
  assert.match(source, /<strong>\{formatWon\(result\.totalEmployeeContribution\)\}<\/strong>/);
});

test("대표 기준소득월액의 국민연금 근로자 부담액은 연봉 계산기와 일치한다", () => {
  const monthlyIncomes = [410_000, 6_000_000, 6_370_000, 6_500_000, 6_590_000, 7_000_000];

  for (const monthlyIncome of monthlyIncomes) {
    const socialInsurance = assertSuccess(
      calculateSocialInsurance({ monthlySalary: monthlyIncome, nonTaxableAmount: 0 }),
    );
    const salaryTakeHome = assertSuccess(
      calculateSalaryTakeHome({
        annualSalary: monthlyIncome * 12,
        monthlyNonTaxableAmount: 0,
        dependentCount: 1,
        childCount: 0,
      }),
    );

    assert.equal(
      socialInsurance.employeePension,
      salaryTakeHome.nationalPension,
      `${monthlyIncome}원 국민연금 부담액`,
    );
  }
});

test("총 공제액과 공제 후 참고 금액이 개별 항목 합계와 일치한다", () => {
  const data = assertSuccess(calculateSocialInsurance(baseInput));
  const expected =
    data.employeePension +
    data.employeeHealthInsurance +
    data.employeeLongTermCare +
    data.employeeEmploymentInsurance;

  assert.equal(data.totalEmployeeContribution, expected);
  assert.equal(
    data.afterContributionAmount,
    data.monthlySalary - data.totalEmployeeContribution,
  );
});

test("빈 값, 숫자 아님, 0 이하, 음수, NaN, Infinity를 거부한다", () => {
  assertHasError(
    calculateSocialInsurance({ monthlySalary: "", nonTaxableAmount: 0 }),
    "monthlySalary",
    "REQUIRED",
  );
  assertHasError(
    calculateSocialInsurance({ monthlySalary: "3000000", nonTaxableAmount: 0 }),
    "monthlySalary",
    "INVALID_NUMBER",
  );
  assertHasError(
    calculateSocialInsurance({ monthlySalary: 0, nonTaxableAmount: 0 }),
    "monthlySalary",
    "MUST_BE_POSITIVE",
  );
  assertHasError(
    calculateSocialInsurance({ monthlySalary: -1, nonTaxableAmount: 0 }),
    "monthlySalary",
    "MUST_BE_POSITIVE",
  );
  assertHasError(
    calculateSocialInsurance({ monthlySalary: Number.NaN, nonTaxableAmount: 0 }),
    "monthlySalary",
    "INVALID_NUMBER",
  );
  assertHasError(
    calculateSocialInsurance({ monthlySalary: Infinity, nonTaxableAmount: 0 }),
    "monthlySalary",
    "INVALID_NUMBER",
  );
  assertHasError(
    calculateSocialInsurance({ monthlySalary: 3_000_000, nonTaxableAmount: -1 }),
    "nonTaxableAmount",
    "MUST_BE_NON_NEGATIVE",
  );
});

test("비과세 금액과 과도한 값을 검증한다", () => {
  assertHasError(
    calculateSocialInsurance({
      monthlySalary: 3_000_000,
      nonTaxableAmount: 3_000_001,
    }),
    "nonTaxableAmount",
    "NON_TAXABLE_EXCEEDS_MONTHLY_SALARY",
  );
  assertHasError(
    calculateSocialInsurance({
      monthlySalary: 3_000_000,
      nonTaxableAmount: 3_000_000,
    }),
    "nonTaxableAmount",
    "TAXABLE_PAY_MUST_BE_POSITIVE",
  );
  assertHasError(
    calculateSocialInsurance({
      monthlySalary: 1_000_000_001,
      nonTaxableAmount: 0,
    }),
    "monthlySalary",
    "AMOUNT_EXCEEDS_LIMIT",
  );
  assertHasError(
    calculateSocialInsurance({
      monthlySalary: Number.MAX_SAFE_INTEGER + 1,
      nonTaxableAmount: 0,
    }),
    "monthlySalary",
    "MUST_BE_SAFE_INTEGER",
  );

  const errors = validateSocialInsuranceInput({
    monthlySalary: 3_000_000.5,
    nonTaxableAmount: 0,
  });
  assert.ok(
    errors.some(
      (error) =>
        error.field === "monthlySalary" && error.code === "MUST_BE_INTEGER",
    ),
  );
});

test("비과세 금액 빈 값은 0원으로 계산한다", () => {
  const data = assertSuccess(
    calculateSocialInsurance({
      monthlySalary: 2_500_000,
      nonTaxableAmount: "",
    }),
  );

  assert.equal(data.nonTaxableAmount, 0);
  assert.equal(data.taxableMonthlyPay, 2_500_000);
});

test("본문 예시 결과는 계산 함수와 같은 값으로 생성된다", () => {
  assert.equal(socialInsuranceExamples.length, 4);
  assert.match(
    socialInsuranceExamples[0].resultItems
      .map(({ value }) => value)
      .join(" "),
    /272,087원/,
  );
});

test("FAQPage JSON-LD는 화면 FAQ와 1:1로 일치한다", () => {
  assert.equal(
    socialInsuranceFaqJsonLd.mainEntity.length,
    socialInsuranceFaqs.length,
  );

  for (const [index, faq] of socialInsuranceFaqs.entries()) {
    const jsonLdFaq = socialInsuranceFaqJsonLd.mainEntity[index];
    assert.equal(jsonLdFaq.name, faq.question);
    assert.equal(jsonLdFaq.acceptedAnswer.text, faq.answer);
  }
});

test("소셜 보험 계산기 페이지는 공개 메타데이터와 계산기 UI를 사용한다", async () => {
  const source = await readFile(
    "app/calculators/social-insurance/page.tsx",
    "utf8",
  );

  assert.doesNotMatch(
    source,
    /isSocialInsuranceCalculatorEnabled|notFound\(\)|index:\s*false/,
  );
  assert.match(source, /canonical/);
  assert.match(source, /index:\s*true/);
  assert.match(source, /<CompactCalculatorHero/);
  assert.match(source, /title="2026 국민연금 납부액·4대보험 계산기"/);
  assert.equal(
    metadata.title,
    "2026 국민연금 납부액·4대보험 계산기 | 월급 기준 근로자 부담액",
  );
  assert.equal(
    metadata.description,
    "월 급여와 비과세 금액을 입력하면 2026년 국민연금·건강보험(장기요양 포함)·고용보험의 근로자 부담액과 월 총 공제액을 계산합니다.",
  );
  assert.equal(
    metadata.openGraph.title,
    "2026 국민연금 납부액·4대보험 계산기 | 월급 기준 근로자 부담액",
  );
  assert.equal(metadata.openGraph.description, metadata.description);
  assert.deepEqual(metadata.robots, { index: true, follow: true });
  assert.deepEqual(metadata.alternates, {
    canonical: "https://gyesanbox.kr/calculators/social-insurance/",
  });
});

test("공식 출처와 외부 링크 보안 속성을 제공한다", async () => {
  const source = await readFile(
    "components/calculators/SocialInsuranceContent.tsx",
    "utf8",
  );

  assert.equal(socialInsuranceSources.length, 5);
  assert.match(source, /rel="noopener noreferrer"/);
  assert.deepEqual(
    socialInsuranceSources.map(({ organization }) => organization),
    [
      "국민연금공단",
      "국민건강보험공단",
      "보건복지부·국민건강보험공단",
      "고용노동부",
      "고용노동부",
    ],
  );
  assert.ok(
    socialInsuranceSources.some(
      ({ title, href }) =>
        title === "월별 건강보험료액의 상한과 하한에 관한 고시" &&
        href ===
          "https://www.nhis.or.kr/lm/lmxsrv/law/lawFullContent.do?SEQ_HISTORY=593928",
    ),
  );

  for (const officialSource of socialInsuranceSources) {
    assert.match(officialSource.href, /^https:\/\//);
    assert.ok(officialSource.criterion.length > 0);
  }
});

test("최종 검토일과 최종 수정일을 공식 자료 확인일과 구분해 표시한다", async () => {
  const source = await readFile(
    "components/calculators/SocialInsuranceContent.tsx",
    "utf8",
  );

  assert.deepEqual(socialInsuranceContentMeta, {
    finalReviewedAt: "2026-07-30",
    lastModifiedAt: "2026-07-30",
  });
  assert.equal((source.match(/최종 검토일/g) ?? []).length, 1);
  assert.equal((source.match(/최종 수정일/g) ?? []).length, 1);
  assert.match(source, /socialInsuranceContentMeta\.finalReviewedAt/);
  assert.match(source, /socialInsuranceContentMeta\.lastModifiedAt/);
  assert.equal(SOCIAL_INSURANCE_POLICY_2026.verifiedAt, "2026-07-10");
});

test("WebApplication JSON-LD에 표준 dateModified만 추가한다", () => {
  assert.equal(socialInsuranceWebApplicationJsonLd["@type"], "WebApplication");
  assert.equal(socialInsuranceWebApplicationJsonLd.dateModified, "2026-07-30");
  assert.equal(
    Object.keys(socialInsuranceWebApplicationJsonLd).filter(
      (key) => key === "dateModified",
    ).length,
    1,
  );
  assert.equal("dateReviewed" in socialInsuranceWebApplicationJsonLd, false);
});

test("월 급여 한도 오류 문구는 자연스러운 조사와 검증용 명칭을 사용한다", async () => {
  const source = await readFile(
    "components/calculators/SocialInsuranceCalculator.tsx",
    "utf8",
  );

  assert.match(source, /monthlySalary: "월 급여 금액"/);
  assert.match(source, /const errorFieldLabels/);
  assert.match(source, /\$\{label\}은 \$\{formatWon\(/);
  assert.match(source, /\$\{label\}이 허용 범위를 벗어났습니다/);
  assert.doesNotMatch(source, /const fieldLabels/);
});

test("sitemap, 목록, 홈과 연봉 관련 계산기에 공개 4대보험 계산기를 노출한다", async () => {
  const files = [
    "lib/site/publicRoutes.ts",
    "app/page.tsx",
    "lib/calculatorRegistry.ts",
    "components/calculators/SalaryTakeHomeContent.tsx",
  ];
  const sources = await Promise.all(files.map((file) => readFile(file, "utf8")));

  for (const source of sources) {
    assert.match(source, /social-insurance|4대보험 계산기/);
  }
});

test("Cloudflare 검증은 social-insurance 산출물을 공개 산출물로 요구한다", async () => {
  const source = await readFile("scripts/verify-cloudflare-pages.mjs", "utf8");

  assert.match(source, /out\/calculators\/social-insurance/);
  assert.match(source, /2026 국민연금 납부액·4대보험 계산기/);
});
