# AdSense 낮은 가치 콘텐츠 대응 기준선 260710

## 반려 사유

- 상태: 광고 게재가 준비되지 않은 사이트
- 상세 사유: 가치가 별로 없는 콘텐츠
- 확인 화면: AdSense 정책 위반 안내

## 운영 기준선

- 기준 커밋: `53c4cb251747e80f3e41e08d31ddfe2ea1e26c44`
- 기준 브랜치: `main`
- 검수 대상 작업 브랜치: `codex/adsense-low-value-content-audit-260710`
- 확인 시각: 2026-07-10 13:19 KST
- 확인 범위: 운영 HTTP/HTML, sitemap/robots/ads.txt, 정적 export 산출물 기준
- 브라우저 시각 검수: 미실시
- Cloudflare Production 환경변수 실제 값: 관리자 화면 직접 확인 안 함

### 공개 URL 12개

일반 공개 페이지 7개:

- `https://gyesanbox.kr/`
- `https://gyesanbox.kr/calculators/`
- `https://gyesanbox.kr/about/`
- `https://gyesanbox.kr/contact/`
- `https://gyesanbox.kr/privacy-policy/`
- `https://gyesanbox.kr/terms/`
- `https://gyesanbox.kr/disclaimer/`

공개 계산기 5개:

- `https://gyesanbox.kr/calculators/seller-margin/`
- `https://gyesanbox.kr/calculators/salary/`
- `https://gyesanbox.kr/calculators/loan/`
- `https://gyesanbox.kr/calculators/severance/`
- `https://gyesanbox.kr/calculators/unemployment/`

위 12개는 운영 HTTP 응답 200, 공개 HTML 접근 가능, 계산기 고유 콘텐츠 노출을 확인한 기준선이다.

### 비공개 계산기 URL 15개

운영 HTTP 요청 기준 최종 404, sitemap 미포함, 공개 HTML 내부 링크 미발견, production export HTML 미생성을 확인한 기준선이다.

- `https://gyesanbox.kr/calculators/social-insurance/`
- `https://gyesanbox.kr/calculators/labor-pay/`
- `https://gyesanbox.kr/calculators/overtime-pay/`
- `https://gyesanbox.kr/calculators/vat-profit/`
- `https://gyesanbox.kr/calculators/dsr/`
- `https://gyesanbox.kr/calculators/roas/`
- `https://gyesanbox.kr/calculators/parental-leave/`
- `https://gyesanbox.kr/calculators/rent-vs-jeonse/`
- `https://gyesanbox.kr/calculators/car-cost/`
- `https://gyesanbox.kr/calculators/savings/`
- `https://gyesanbox.kr/calculators/average-price/`
- `https://gyesanbox.kr/calculators/brokerage-fee/`
- `https://gyesanbox.kr/calculators/card-installment/`
- `https://gyesanbox.kr/calculators/youth-future-savings/`
- `https://gyesanbox.kr/calculators/work-child-incentive/`

### 시스템 파일과 스크립트

- sitemap.xml: 200, 공개 URL 12개만 포함
- robots.txt: 200, wildcard 전체 차단 없음, apex sitemap 유지
- ads.txt: 200, 기존 Google publisher 항목 유지
- GA4: 공개 HTML에서 `G-YMJFLPRFMV` 감지
- AdSense: 공개 HTML별 script 1회 감지, 중복 없음
- Cloudflare email protection 관련 문자열: 공개 HTML에서 미감지
- `www.gyesanbox.kr` 및 `http://gyesanbox.kr`: 공개 HTML에서 미감지
- 정적 export pruning: 기본 production build 산출물에서 비공개 계산기 HTML 미생성
- 기능 플래그: 비공개 계산기는 strict `"true"` 외 값에서 공개하지 않는 정책 유지
- 사용자 제공 정보: AdSense 관리자 화면의 반려 상태와 사유
- 직접 확인 정보: 저장소 코드, 운영 HTML 문자열, HTTP 응답, 정적 export 산출물
- 확인하지 않은 항목: AdSense 관리자 화면 내부 재검토 가능 조건, Cloudflare 관리자 화면의 환경변수 실제 값, 브라우저 렌더링 육안 검수

## 공개 계산기 5개 콘텐츠 감사

### 판매자 마진 계산기

- 강점: 주문 단위 예시, 12개 계산식, 제외 항목, FAQ, 관련 계산기 링크가 있음.
- 보강 필요: 공식 참고 출처와 세금 신고 기준 차이 설명이 상대적으로 약했음.
- 조치: 부가가치세, 종합소득세 공식 출처와 실제 정산·신고 금액 차이 설명을 추가.

### 연봉 실수령액 계산기

- 강점: 2026년 정책 기준, 기준일, 엔진 기반 예시, 공식 출처, 제외 항목, FAQ가 균형 있게 구성됨.
- 보강 필요: 당장 P1 보강 없음. 향후 독립 정보 가이드에서 급여명세서 차이 원인을 별도 문서로 풀어내면 좋음.

### 대출 이자 계산기

- 강점: 상환방식 비교, 계산식, 예시, 해석 카드, 제외 항목, 공식 출처가 있음.
- 보강 필요: 당장 P1 보강 없음. 향후 상환방식별 월 납입액 차이를 독립 가이드로 분리 가능.

### 퇴직금 계산기

- 강점: 공식 예제 기반 입력·결과, 계산 기준, 계산식, 예외 및 주의사항, 공식 출처가 있음.
- 보강 필요: 당장 P1 보강 없음. 향후 상여금·수당 반영 방법을 독립 가이드로 분리 가능.

### 실업급여 계산기

- 강점: 2026년 기준, 신청 전 체크리스트, 계산 기준 표, 절차 안내, 공식 출처가 풍부함.
- 보강 필요: 당장 P1 보강 없음. 향후 피보험 단위기간 180일 확인 방법을 독립 가이드로 분리 가능.

## 다음 작업 제안

1. 판매자 마진 보강 검증 후 커밋한다.
2. 기존 공개 계산기 5개의 중복 FAQ와 공통 면책 문구를 추가로 정량 점검한다.
3. 첫 번째 비공개 공개 후보인 2026 4대보험 계산기 파일과 테스트가 현재 main에 존재하는지 확인한다.
4. 공개 전 검수 브랜치에서 4대보험 계산기를 단독으로 복원·검증한다.
