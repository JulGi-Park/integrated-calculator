import type { Metadata } from "next";
import Link from "next/link";
import { JsonLdScripts } from "@/components/common/JsonLdScripts";
import { SocialInsuranceCalculator } from "@/components/calculators/SocialInsuranceCalculator";
import { SocialInsuranceContent } from "@/components/calculators/SocialInsuranceContent";
import { CompactCalculatorHero } from "@/components/common/CompactCalculatorHero";
import {
  socialInsuranceBreadcrumbJsonLd,
  socialInsuranceFaqJsonLd,
  socialInsuranceWebApplicationJsonLd,
} from "@/components/calculators/socialInsuranceContentData";
import { SOCIAL_INSURANCE_POLICY_2026 } from "@/lib/calculators/social-insurance/constants";
import { PUBLIC_CALCULATOR_SEO } from "@/lib/seo/publicCalculatorSeo";

const seo = PUBLIC_CALCULATOR_SEO["social-insurance"];
const { title, description } = seo;
const ogTitle = "2026 국민연금 납부액·4대보험 계산기 | 월급 기준 근로자 부담액";
const canonical = "https://gyesanbox.kr/calculators/social-insurance/";
const ogImage = seo.image;

export const metadata: Metadata = {
  title,
  description,
  robots: {
    index: true,
    follow: true,
  },
  alternates: {
    canonical,
  },
  openGraph: {
    title: ogTitle,
    description,
    url: canonical,
    type: "website",
    images: [
      {
        url: ogImage,
        width: 1200,
        height: 630,
        alt: ogTitle,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: ogTitle,
    description,
    images: [ogImage],
  },
};

function formatKoreanDate(value: string): string {
  const [year, month, day] = value.split("-").map(Number);
  return `${year}년 ${month}월 ${day}일`;
}

export default function SocialInsurancePage() {
  const jsonLdItems = [
    { ...socialInsuranceWebApplicationJsonLd, image: ogImage },
    socialInsuranceBreadcrumbJsonLd,
    socialInsuranceFaqJsonLd,
  ];

  return (
    <section className="page-section salary-page">
      <JsonLdScripts items={jsonLdItems} />

      <CompactCalculatorHero
        className="seller-margin-heading"
        eyebrow="Social insurance"
        title="2026 국민연금 납부액·4대보험 계산기"
        description={
          <>
          월 급여와 비과세 금액을 입력해 국민연금 납부액을 포함한
          4대보험 근로자 부담 공제액을 계산합니다. 국민연금은
          기준소득월액 하한·상한과 절사 기준을 반영합니다.
          </>
        }
        meta={
          <>
          <span>기준 확인일: {formatKoreanDate(SOCIAL_INSURANCE_POLICY_2026.verifiedAt)}</span>
          <span>산재보험은 자동 계산에서 제외됩니다.</span>
          <span>소득세와 지방소득세는 포함하지 않습니다.</span>
          </>
        }
      />

      <SocialInsuranceCalculator />
      <SocialInsuranceContent />

      <nav className="link-row seller-margin-links" aria-label="페이지 이동">
        <a className="text-link" href="/calculators/">
          ← 계산기 목록
        </a>
        <Link className="text-link" href="/">
          홈으로
        </Link>
      </nav>
    </section>
  );
}
