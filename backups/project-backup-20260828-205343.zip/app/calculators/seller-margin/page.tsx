import type { Metadata } from "next";
import Link from "next/link";
import { JsonLdScripts } from "@/components/common/JsonLdScripts";
import { SellerMarginCalculator } from "@/components/calculators/SellerMarginCalculator";
import { SellerMarginContent } from "@/components/calculators/SellerMarginContent";
import { CompactCalculatorHero } from "@/components/common/CompactCalculatorHero";
import { PUBLIC_CALCULATOR_SEO } from "@/lib/seo/publicCalculatorSeo";
import {
  sellerMarginBreadcrumbJsonLd,
  sellerMarginFaqJsonLd,
  sellerMarginWebApplicationJsonLd,
} from "@/components/calculators/sellerMarginContentData";

const seo = PUBLIC_CALCULATOR_SEO["seller-margin"];
const { title, description } = seo;
const ogTitle = "판매자 마진 계산기 | 판매금액에서 비용을 뺀 예상 순이익";
const ogDescription =
  "판매가와 수량을 입력하고 원가·할인·배송비·수수료·광고비·기타 비용을 반영해 예상 정산금액, 순이익과 순이익률을 계산합니다.";
const ogUrl = seo.path.startsWith("/") ? `https://gyesanbox.kr${seo.path}` : seo.path;
const ogImage = seo.image;

export const metadata: Metadata = {
  title,
  description,
  robots: {
    index: true,
    follow: true,
  },
  alternates: {
    canonical: ogUrl,
  },
  openGraph: {
    title: ogTitle,
    description: ogDescription,
    url: ogUrl,
    type: "website",
    images: [
      {
        url: ogImage,
        width: 1200,
        height: 630,
        alt: ogTitle,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: ogTitle,
    description: ogDescription,
    images: [ogImage],
  },
};

export default function SellerMarginPage() {
  const jsonLdItems = [
    { ...sellerMarginWebApplicationJsonLd, image: ogImage },
    sellerMarginBreadcrumbJsonLd,
    sellerMarginFaqJsonLd,
  ];

  return (
    <section className="page-section seller-margin-page">
      <JsonLdScripts items={jsonLdItems} />

      <CompactCalculatorHero
        className="seller-margin-heading"
        eyebrow="Seller margin"
        title="판매자 마진 계산기"
        description={
          <>
          판매가와 수량으로 판매금액을 확인하고 원가, 할인, 배송비, 수수료와
          광고비를 반영해 주문 기준 예상 정산금액과 순이익을 계산할 수 있습니다.
          </>
        }
        meta={
          <>
          <span>계산 기준일: 2026년 6월 18일</span>
          <span>
            계산 결과는 입력값을 기준으로 산출한 세전 예상값이며 실제 플랫폼
            정산액과 다를 수 있습니다.
          </span>
          </>
        }
      />

      <SellerMarginCalculator />
      <SellerMarginContent />

      <nav className="link-row seller-margin-links" aria-label="페이지 이동">
        <a className="text-link" href="/calculators/">
          ← 계산기 목록
        </a>
        <Link className="text-link" href="/">
          홈으로
        </Link>
      </nav>
    </section>
  );
}
